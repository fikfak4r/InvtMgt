/// <reference path="../../../Kendo/typescript/kendo.all.d.ts" />
/// <reference path="../../../Kendo/typescript/jquery.d.ts" />
namespace CustomerSupport.BusinessObjects {
    
        export class TransactionLoader {
    
            protected transactionDtlFrm: kendo.data.ObservableObject;
            protected fitlerPane: kendo.data.ObservableObject;
            protected transactionListDtSrc: kendo.data.DataSource;
    
    
            constructor() {
    
                // this.transactionDtlFrm = kendo.observable({
                //     ddl: [{ text: "", val: "" }],
                //     getObject: function () {
                //     }
                // })//Ends this.transactionList
    
                // kendo.bind($("#transaction-dtl-form"), this.transactionDtlFrm)
    
    
                // this.fitlerPane = kendo.observable({
    
                //     getObject: function () {
                //     }
                // })//Ends this.fitlerPane
    
                    this.transactionListDtSrc = new kendo.data.DataSource({
                    schema: {
                    //data: function (response) { alert(JSON.stringify(response)); return response.Entities; },
                     data:"Entities",
                     total: "TotalCount",
                     model: {
                      id: "TransactionId",
                      fields: {
                      },
                     }
                    },
                    batch: false,
                    pageSize: 5,
                    transport: {
                     read: function (options) {
                        //    ClassNameService.List({},
                        //       res => {s
                        //               //options.success(res);
                        //               options.success(res);
                        //       })
    
                        options.success({Entities:[{TransactionId:1, Subject:"Subj 1"},{TransactionId:2, Subject:"Subj 2"}],TotalCount:2})

                            },
                     create: function (options) {
                            // ClassNameService.Create({ Entity: JSON.parse( Q.replaceAll(JSON.stringify(options.data), '"TransactionId":0,', '')) },
                            //      res => {
                            //           options.success(res);
                            //   })
                            }
                    },
                    })//Ends
    
    
            }
    
    
    
    
    
            public Load(): void {
                //alert($("#transaction-template").html())
                    // $("#transaction-list").kendoListView({
                    //   dataSource: this.transactionListDtSrc,
                    //    template:kendo.template($("#transaction-template").html())
                    //  })
    
    
    
    	// $("#transaction-list").kendoListView({
        //   dataSource: this.transactionListDtSrc,
        //    template:kendo.template($("#transaction-template").html())
        //  })

        $("#transaction-list").kendoGrid({
            dataSource:this.transactionListDtSrc,
            columns:[{selectable:true,width:"50px"},
                {field:"OrderId"},
                {field:"Date"},
                {field:"Customer"},
                {field:"Subject"},
                {field:"Amount"},
                {field:"Paid"},
                {field:"Balance"}                
            ],

            })
    
                     $("#pager").kendoPager({
                    dataSource: this.transactionListDtSrc,
                    });
                    $("#pager2").kendoPager({
                        dataSource: this.transactionListDtSrc,
                        });
            }
    
    
        protected transactionMessageSection: kendo.data.ObservableObject;
            public FormLoader():void{
    
                $("#new-transaction-tab").kendoTabStrip({

                })
                 
            }
    
    
        }
    }