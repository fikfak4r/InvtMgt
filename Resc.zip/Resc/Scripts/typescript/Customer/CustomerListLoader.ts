/// <reference path="../../../Kendo/typescript/kendo.all.d.ts" />
/// <reference path="../../../Kendo/typescript/jquery.d.ts" />
namespace CustomerSupport.BusinessObjects {
    
        export class CustomerLoader {
    
            protected customerDtlFrm: kendo.data.ObservableObject;
            protected fitlerPane: kendo.data.ObservableObject;
            protected customerListDtSrc: kendo.data.DataSource;
    
    
            constructor() {
    
                this.customerDtlFrm = kendo.observable({
                    ddl: [{ text: "", val: "" }],
                    getObject: function () {
                    }
                })//Ends this.customerList
    
                kendo.bind($("#customer-dtl-form"), this.customerDtlFrm)
    
    
                // this.fitlerPane = kendo.observable({
    
                //     getObject: function () {
                //     }
                // })//Ends this.fitlerPane
    
                    this.customerListDtSrc = new kendo.data.DataSource({
                    schema: {
                    //data: function (response) { alert(JSON.stringify(response)); return response.Entities; },
                     data:"Entities",
                     total: "TotalCount",
                     model: {
                      id: "CustomerId",
                      fields: {
                      },
                     }
                    },
                    batch: false,
                    pageSize: 5,
                    transport: {
                     read: function (options) {
                        //    ClassNameService.List({},
                        //       res => {s
                        //               //options.success(res);
                        //               options.success(res);
                        //       })
    
                        options.success({Entities:[{CustomerId:1, Subject:"Subj 1"},{CustomerId:2, Subject:"Subj 2"}],TotalCount:2})

                            },
                     create: function (options) {
                            // ClassNameService.Create({ Entity: JSON.parse( Q.replaceAll(JSON.stringify(options.data), '"CustomerId":0,', '')) },
                            //      res => {
                            //           options.success(res);
                            //   })
                            }
                    },
                    })//Ends
    
    
            }
    
    
    
    
    
            public Load(): void {
                //alert($("#customer-template").html())
                    // $("#customer-list").kendoListView({
                    //   dataSource: this.customerListDtSrc,
                    //    template:kendo.template($("#customer-template").html())
                    //  })
    
    
    
    	// $("#customer-list").kendoListView({
        //   dataSource: this.customerListDtSrc,
        //    template:kendo.template($("#customer-template").html())
        //  })

        $("#customer-list").kendoGrid({
            dataSource:this.customerListDtSrc,
            columns:[{selectable:true,width:"50px"},
                {field:"Subject"},
                {field:"Requester"},
                {field:"Date"},
                {template:"<span class='label label-success'>Open</span>",title:"Status"},
                
            ],

            })
    
                     $("#pager").kendoPager({
                    dataSource: this.customerListDtSrc,
                    });
                    $("#pager2").kendoPager({
                        dataSource: this.customerListDtSrc,
                        });
            }
    
    
        protected customerMessageSection: kendo.data.ObservableObject;
            public FormLoader():void{
    
                $("#new-customer-tab").kendoTabStrip({

                })
                 
            }
    
    
        }
    }