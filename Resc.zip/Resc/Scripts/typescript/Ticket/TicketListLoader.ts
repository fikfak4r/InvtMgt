/// <reference path="../../../Kendo/typescript/kendo.all.d.ts" />
/// <reference path="../../../Kendo/typescript/jquery.d.ts" />
namespace CustomerSupport.BusinessObjects {

    export class TicketLoader {

        protected ticketList: kendo.data.ObservableObject;
        protected fitlerPane: kendo.data.ObservableObject;
        protected ticketListDtSrc: kendo.data.DataSource;


        constructor() {

            this.ticketList = kendo.observable({
                ddl: [{ text: "", val: "" }],
                getObject: function () {
                }
            })//Ends this.ticketList

            kendo.bind($("#ticket-list"), this.ticketList)


            this.fitlerPane = kendo.observable({

                getObject: function () {
                }
            })//Ends this.fitlerPane
            kendo.bind($("#filter-pane"), this.fitlerPane)

            	this.ticketListDtSrc = new kendo.data.DataSource({
                schema: {
                //data: function (response) { alert(JSON.stringify(response)); return response.Entities; },
                 data:"Entities",
                 total: "TotalCount",
                 model: {
                  id: "TicketId",
                  fields: {
                  },
                 }
                },
                batch: false,
                pageSize: 5,
                transport: {
                 read: function (options) {
                    //    ClassNameService.List({},
                    //       res => {s
                    //               //options.success(res);
                    //               options.success(res);
                    //       })

                    options.success({Entities:[{TicketId:1, Subject:"Subj 1"},{TicketId:2, Subject:"Subj 2"}],TotalCount:2})
                        },
                 create: function (options) {
                        // ClassNameService.Create({ Entity: JSON.parse( Q.replaceAll(JSON.stringify(options.data), '"TicketId":0,', '')) },
                        //      res => {
                        //           options.success(res);
                        //   })
                        }
                },
                })//Ends


        }





        public Load(): void {
            //alert($("#ticket-template").html())
            	// $("#ticket-list").kendoListView({
                //   dataSource: this.ticketListDtSrc,
                //    template:kendo.template($("#ticket-template").html())
                //  })






                    $("#ticket-list").kendoGrid({
                        dataSource:this.ticketListDtSrc,
                        columns:[{selectable:true,width:"50px"},
                            {field:"Subject"},
                            {field:"Requester"},
                            {field:"Date"},
                            {template:"<span class='label label-success'>Open</span>",title:"Status"},
                            
                        ],

                        })


                 $("#pager").kendoPager({
                dataSource: this.ticketListDtSrc,
                });
                $("#pager2").kendoPager({
                    dataSource: this.ticketListDtSrc,
                    });
        }


    protected ticketMessageSection: kendo.data.ObservableObject;
        public FormLoader():void{

            	this.ticketMessageSection = kendo.observable({
                action:[{text:"In-coming-call"},{text:"Out-going-call"},{text:"Reply"},{text:"Comment"},{text:"Note"},{text:"Complain"}],
                actionVal:null,
                getObject: function () {
                    alert(this.actionVal.text)
                }
                })//Ends this.ticketMessageSection
                kendo.bind($("#ticket-message-section"), this.ticketMessageSection)

                    $("#vertical-splitter").kendoSplitter({
                        orientation:"vertical",
                        panes:[{collapsible:true,size:"280px"},{collapsible:true}]

                    })
        }


    }
}