class Startup {
    public static main(): number {
        //alert("Yup ... Hello world!  Sign of a victory")
        console.log('Hello World');
        return 0;
    }
}

Startup.main();