﻿/// <reference path="../../Kendo/typescript/kendo.all.d.ts" />
/// <reference path="../../Kendo/typescript/jquery.d.ts" />
declare class Startup {
    static main(): number;
}
declare namespace CustomerSupport.BusinessObjects {
    class CustomerLoader {
        protected customerDtlFrm: kendo.data.ObservableObject;
        protected fitlerPane: kendo.data.ObservableObject;
        protected customerListDtSrc: kendo.data.DataSource;
        constructor();
        Load(): void;
        protected customerMessageSection: kendo.data.ObservableObject;
        FormLoader(): void;
    }
}
declare namespace CustomerSupport.BusinessObjects {
    class TicketLoader {
        protected ticketList: kendo.data.ObservableObject;
        protected fitlerPane: kendo.data.ObservableObject;
        protected ticketListDtSrc: kendo.data.DataSource;
        constructor();
        Load(): void;
        protected ticketMessageSection: kendo.data.ObservableObject;
        FormLoader(): void;
    }
}
declare namespace CustomerSupport.BusinessObjects {
    class TransactionDetail {
        protected calcObservable: kendo.data.ObservableObject;
        protected customerInfoObservable: kendo.data.ObservableObject;
        protected transactionDetailsDtSrc: kendo.data.DataSource;
        static CalcObservable_Static: kendo.data.ObservableObject;
        static CustomerInfoObservable_Static: kendo.data.ObservableObject;
        constructor();
        static CalculatorObservable(): kendo.data.ObservableObject;
        static CustomerInfoObservable(): kendo.data.ObservableObject;
        static DltGrdDataSource(): kendo.data.DataSource;
        Load(): void;
        static Submit(): void;
    }
}
declare namespace CustomerSupport.BusinessObjects {
    class TransactionLoader {
        protected transactionDtlFrm: kendo.data.ObservableObject;
        protected fitlerPane: kendo.data.ObservableObject;
        protected transactionListDtSrc: kendo.data.DataSource;
        constructor();
        Load(): void;
        protected transactionMessageSection: kendo.data.ObservableObject;
        FormLoader(): void;
    }
}
