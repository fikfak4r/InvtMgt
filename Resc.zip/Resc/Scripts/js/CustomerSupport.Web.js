﻿var Startup = /** @class */ (function () {
    function Startup() {
    }
    Startup.main = function () {
        //alert("Yup ... Hello world!  Sign of a victory")
        console.log('Hello World');
        return 0;
    };
    return Startup;
}());
Startup.main();
/// <reference path="../../../Kendo/typescript/kendo.all.d.ts" />
/// <reference path="../../../Kendo/typescript/jquery.d.ts" />
var CustomerSupport;
(function (CustomerSupport) {
    var BusinessObjects;
    (function (BusinessObjects) {
        var CustomerLoader = /** @class */ (function () {
            function CustomerLoader() {
                this.customerDtlFrm = kendo.observable({
                    ddl: [{ text: "", val: "" }],
                    getObject: function () {
                    }
                }); //Ends this.customerList
                kendo.bind($("#customer-dtl-form"), this.customerDtlFrm);
                // this.fitlerPane = kendo.observable({
                //     getObject: function () {
                //     }
                // })//Ends this.fitlerPane
                this.customerListDtSrc = new kendo.data.DataSource({
                    schema: {
                        //data: function (response) { alert(JSON.stringify(response)); return response.Entities; },
                        data: "Entities",
                        total: "TotalCount",
                        model: {
                            id: "CustomerId",
                            fields: {},
                        }
                    },
                    batch: false,
                    pageSize: 5,
                    transport: {
                        read: function (options) {
                            //    ClassNameService.List({},
                            //       res => {s
                            //               //options.success(res);
                            //               options.success(res);
                            //       })
                            options.success({ Entities: [{ CustomerId: 1, Subject: "Subj 1" }, { CustomerId: 2, Subject: "Subj 2" }], TotalCount: 2 });
                        },
                        create: function (options) {
                            // ClassNameService.Create({ Entity: JSON.parse( Q.replaceAll(JSON.stringify(options.data), '"CustomerId":0,', '')) },
                            //      res => {
                            //           options.success(res);
                            //   })
                        }
                    },
                }); //Ends
            }
            CustomerLoader.prototype.Load = function () {
                //alert($("#customer-template").html())
                // $("#customer-list").kendoListView({
                //   dataSource: this.customerListDtSrc,
                //    template:kendo.template($("#customer-template").html())
                //  })
                // $("#customer-list").kendoListView({
                //   dataSource: this.customerListDtSrc,
                //    template:kendo.template($("#customer-template").html())
                //  })
                $("#customer-list").kendoGrid({
                    dataSource: this.customerListDtSrc,
                    columns: [{ selectable: true, width: "50px" },
                        { field: "Subject" },
                        { field: "Requester" },
                        { field: "Date" },
                        { template: "<span class='label label-success'>Open</span>", title: "Status" },
                    ],
                });
                $("#pager").kendoPager({
                    dataSource: this.customerListDtSrc,
                });
                $("#pager2").kendoPager({
                    dataSource: this.customerListDtSrc,
                });
            };
            CustomerLoader.prototype.FormLoader = function () {
                $("#new-customer-tab").kendoTabStrip({});
            };
            return CustomerLoader;
        }());
        BusinessObjects.CustomerLoader = CustomerLoader;
    })(BusinessObjects = CustomerSupport.BusinessObjects || (CustomerSupport.BusinessObjects = {}));
})(CustomerSupport || (CustomerSupport = {}));
/// <reference path="../../../Kendo/typescript/kendo.all.d.ts" />
/// <reference path="../../../Kendo/typescript/jquery.d.ts" />
var CustomerSupport;
(function (CustomerSupport) {
    var BusinessObjects;
    (function (BusinessObjects) {
        var TicketLoader = /** @class */ (function () {
            function TicketLoader() {
                this.ticketList = kendo.observable({
                    ddl: [{ text: "", val: "" }],
                    getObject: function () {
                    }
                }); //Ends this.ticketList
                kendo.bind($("#ticket-list"), this.ticketList);
                this.fitlerPane = kendo.observable({
                    getObject: function () {
                    }
                }); //Ends this.fitlerPane
                kendo.bind($("#filter-pane"), this.fitlerPane);
                this.ticketListDtSrc = new kendo.data.DataSource({
                    schema: {
                        //data: function (response) { alert(JSON.stringify(response)); return response.Entities; },
                        data: "Entities",
                        total: "TotalCount",
                        model: {
                            id: "TicketId",
                            fields: {},
                        }
                    },
                    batch: false,
                    pageSize: 5,
                    transport: {
                        read: function (options) {
                            //    ClassNameService.List({},
                            //       res => {s
                            //               //options.success(res);
                            //               options.success(res);
                            //       })
                            options.success({ Entities: [{ TicketId: 1, Subject: "Subj 1" }, { TicketId: 2, Subject: "Subj 2" }], TotalCount: 2 });
                        },
                        create: function (options) {
                            // ClassNameService.Create({ Entity: JSON.parse( Q.replaceAll(JSON.stringify(options.data), '"TicketId":0,', '')) },
                            //      res => {
                            //           options.success(res);
                            //   })
                        }
                    },
                }); //Ends
            }
            TicketLoader.prototype.Load = function () {
                //alert($("#ticket-template").html())
                // $("#ticket-list").kendoListView({
                //   dataSource: this.ticketListDtSrc,
                //    template:kendo.template($("#ticket-template").html())
                //  })
                $("#ticket-list").kendoGrid({
                    dataSource: this.ticketListDtSrc,
                    columns: [{ selectable: true, width: "50px" },
                        { field: "Subject" },
                        { field: "Requester" },
                        { field: "Date" },
                        { template: "<span class='label label-success'>Open</span>", title: "Status" },
                    ],
                });
                $("#pager").kendoPager({
                    dataSource: this.ticketListDtSrc,
                });
                $("#pager2").kendoPager({
                    dataSource: this.ticketListDtSrc,
                });
            };
            TicketLoader.prototype.FormLoader = function () {
                this.ticketMessageSection = kendo.observable({
                    action: [{ text: "In-coming-call" }, { text: "Out-going-call" }, { text: "Reply" }, { text: "Comment" }, { text: "Note" }, { text: "Complain" }],
                    actionVal: null,
                    getObject: function () {
                        alert(this.actionVal.text);
                    }
                }); //Ends this.ticketMessageSection
                kendo.bind($("#ticket-message-section"), this.ticketMessageSection);
                $("#vertical-splitter").kendoSplitter({
                    orientation: "vertical",
                    panes: [{ collapsible: true, size: "280px" }, { collapsible: true }]
                });
            };
            return TicketLoader;
        }());
        BusinessObjects.TicketLoader = TicketLoader;
    })(BusinessObjects = CustomerSupport.BusinessObjects || (CustomerSupport.BusinessObjects = {}));
})(CustomerSupport || (CustomerSupport = {}));
/// <reference path="../../../Kendo/typescript/kendo.all.d.ts" />
/// <reference path="../../../Kendo/typescript/jquery.d.ts" />
var CustomerSupport;
(function (CustomerSupport) {
    var BusinessObjects;
    (function (BusinessObjects) {
        var TransactionDetail = /** @class */ (function () {
            function TransactionDetail() {
                this.calcObservable = kendo.observable({
                    CalculateAmount: function (dataItem) {
                        return dataItem.Quantity * dataItem.UnitPrice;
                    },
                    CalculateTotalAmount: function (gridRef) {
                        alert('in calc');
                        var items = gridRef.items();
                        var rowCount = items.length - 1;
                        var ttlAmt = 0;
                        for (var x = 0; x < items.length; x++) {
                            ttlAmt += this.CalculateAmount(gridRef.dataItem(items[x]));
                        }
                        this.set("totalAmountProp", ttlAmt);
                        alert(ttlAmt);
                        alert(this.get("totalAmountProp"));
                    },
                    totalAmountProp: 0,
                    paid: 0,
                    discount: 0,
                    tax: 0,
                    grandTotal: 0,
                    calculateGrandTotal: function () {
                        var discount = 0;
                        var tax = 0;
                        var totalPaid = this.get("paid");
                        var totalAmount = this.get("totalAmountProp");
                        if (this.get("tax") > 0 && isNaN(this.get("tax"))) {
                            tax = (this.get("tax") / 100) * totalAmount;
                        }
                        if (this.get("discount") > 0 && isNaN(this.get("discount"))) {
                            tax = (this.get("discount") / 100) * totalAmount;
                        }
                        var paid = totalAmount - discount;
                        paid = paid + tax;
                        this.set("paid", paid);
                        this.set("grandTotal", paid);
                    }
                }); //Ends calcObservable
                kendo.bind($("#total-amt-calc"), this.calcObservable);
                TransactionDetail.CalcObservable_Static = this.calcObservable;
                this.customerInfoObservable = kendo.observable({
                    date: null,
                    name: "Fikoli",
                    email: "fik@yahoo.com",
                    phoneNumber: "080",
                    customerInfo: function () {
                        return { date: this.get("date"), name: this.get("name"), email: this.get("email"), phoneNumber: this.get("phoneNumber") };
                    }
                });
                kendo.bind($("#customer-info"), this.customerInfoObservable);
                TransactionDetail.CustomerInfoObservable_Static = this.customerInfoObservable;
                this.transactionDetailsDtSrc = new kendo.data.DataSource({
                    schema: {
                        model: {
                            id: "TransactionDetailId",
                            fields: {
                                TransactionDetailId: { type: "number" },
                                TransactionId: { type: "number" },
                                Date: { type: "number" },
                                ProductName: { type: "string" },
                            }
                        },
                    },
                    pageSize: 20,
                    transport: {
                        create: function (options) {
                            //options.
                        },
                        update: function (options) { }
                    }
                });
            }
            TransactionDetail.CalculatorObservable = function () {
                return;
            };
            TransactionDetail.CustomerInfoObservable = function () {
                return;
            };
            TransactionDetail.DltGrdDataSource = function () {
                var inMem = [{ Product: "Samsung", Quantity: "1", UnitPrice: "105000", Amount: "105000" }];
                var dtSrc = new kendo.data.DataSource({
                    schema: {
                        model: {
                            id: "",
                            fields: {
                                Product: { type: "string" },
                                Quantity: { type: "number" },
                                UnitPrice: { type: "number" },
                                Amount: { type: "number" }
                            }
                        }
                    },
                    transport: {
                        read: function (options) {
                            options.success(inMem);
                        }
                    }
                }); //Ends dtSrc
                return dtSrc;
            };
            TransactionDetail.prototype.Load = function () {
                $("#customer-date").kendoDatePicker();
                var trax_dtl_grd = $("#transaction-dtl-grd").kendoGrid({
                    dataSource: TransactionDetail.DltGrdDataSource(),
                    columns: [
                        { field: "Product" },
                        { field: "Quantity" },
                        { field: "UnitPrice", title: "Unit price" },
                        { field: "Amount" },
                    ],
                    editable: {
                        createAt: "bottom",
                    },
                    navigatable: true,
                    cellClose: function (e) {
                    }
                }).data("kendoGrid");
                trax_dtl_grd.addRow();
                trax_dtl_grd.tbody.on('keydown', function (e) {
                    if ($(e.target).closest('td').is(':last-child') && $(e.target).closest('tr').is(':last-child')) {
                        trax_dtl_grd.addRow();
                        TransactionDetail.CalcObservable_Static.CalculateTotalAmount(trax_dtl_grd);
                        TransactionDetail.CalcObservable_Static.calculateGrandTotal();
                    }
                });
                $("#customer-list-ddl").kendoAutoComplete({
                    dataSource: ["Data 1", "Data 2"],
                    placeholder: "Select customer"
                });
            }; //Ends the Load method
            TransactionDetail.Submit = function () {
                alert(kendo.stringify(TransactionDetail.CustomerInfoObservable_Static.customerInfo()));
                $("#transaction-dtl-grd").data("kendoGrid").saveChanges();
            };
            return TransactionDetail;
        }());
        BusinessObjects.TransactionDetail = TransactionDetail;
    })(BusinessObjects = CustomerSupport.BusinessObjects || (CustomerSupport.BusinessObjects = {}));
})(CustomerSupport || (CustomerSupport = {}));
/// <reference path="../../../Kendo/typescript/kendo.all.d.ts" />
/// <reference path="../../../Kendo/typescript/jquery.d.ts" />
var CustomerSupport;
(function (CustomerSupport) {
    var BusinessObjects;
    (function (BusinessObjects) {
        var TransactionLoader = /** @class */ (function () {
            function TransactionLoader() {
                // this.transactionDtlFrm = kendo.observable({
                //     ddl: [{ text: "", val: "" }],
                //     getObject: function () {
                //     }
                // })//Ends this.transactionList
                // kendo.bind($("#transaction-dtl-form"), this.transactionDtlFrm)
                // this.fitlerPane = kendo.observable({
                //     getObject: function () {
                //     }
                // })//Ends this.fitlerPane
                this.transactionListDtSrc = new kendo.data.DataSource({
                    schema: {
                        //data: function (response) { alert(JSON.stringify(response)); return response.Entities; },
                        data: "Entities",
                        total: "TotalCount",
                        model: {
                            id: "TransactionId",
                            fields: {},
                        }
                    },
                    batch: false,
                    pageSize: 5,
                    transport: {
                        read: function (options) {
                            //    ClassNameService.List({},
                            //       res => {s
                            //               //options.success(res);
                            //               options.success(res);
                            //       })
                            options.success({ Entities: [{ TransactionId: 1, Subject: "Subj 1" }, { TransactionId: 2, Subject: "Subj 2" }], TotalCount: 2 });
                        },
                        create: function (options) {
                            // ClassNameService.Create({ Entity: JSON.parse( Q.replaceAll(JSON.stringify(options.data), '"TransactionId":0,', '')) },
                            //      res => {
                            //           options.success(res);
                            //   })
                        }
                    },
                }); //Ends
            }
            TransactionLoader.prototype.Load = function () {
                //alert($("#transaction-template").html())
                // $("#transaction-list").kendoListView({
                //   dataSource: this.transactionListDtSrc,
                //    template:kendo.template($("#transaction-template").html())
                //  })
                // $("#transaction-list").kendoListView({
                //   dataSource: this.transactionListDtSrc,
                //    template:kendo.template($("#transaction-template").html())
                //  })
                $("#transaction-list").kendoGrid({
                    dataSource: this.transactionListDtSrc,
                    columns: [{ selectable: true, width: "50px" },
                        { field: "OrderId" },
                        { field: "Date" },
                        { field: "Customer" },
                        { field: "Subject" },
                        { field: "Amount" },
                        { field: "Paid" },
                        { field: "Balance" }
                    ],
                });
                $("#pager").kendoPager({
                    dataSource: this.transactionListDtSrc,
                });
                $("#pager2").kendoPager({
                    dataSource: this.transactionListDtSrc,
                });
            };
            TransactionLoader.prototype.FormLoader = function () {
                $("#new-transaction-tab").kendoTabStrip({});
            };
            return TransactionLoader;
        }());
        BusinessObjects.TransactionLoader = TransactionLoader;
    })(BusinessObjects = CustomerSupport.BusinessObjects || (CustomerSupport.BusinessObjects = {}));
})(CustomerSupport || (CustomerSupport = {}));
//# sourceMappingURL=CustomerSupport.Web.js.map