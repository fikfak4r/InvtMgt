﻿namespace CustomerSupport.BusinessObjects {
    export enum Gender {
        Female = 1,
        Male = 2
    }
    Serenity.Decorators.registerEnum(Gender, 'BusinessObjects.Gender');
}

