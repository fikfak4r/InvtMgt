﻿namespace CustomerSupport {
    export interface ExcelImportRequest extends Serenity.ServiceRequest {
        FileName?: string;
    }
}

