﻿namespace CustomerSupport.Administration {
    export interface RolePermissionListResponse extends Serenity.ListResponse<string> {
    }
}

