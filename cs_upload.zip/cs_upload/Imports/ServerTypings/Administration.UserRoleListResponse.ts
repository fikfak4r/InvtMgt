﻿namespace CustomerSupport.Administration {
    export interface UserRoleListResponse extends Serenity.ListResponse<number> {
    }
}

