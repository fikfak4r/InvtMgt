﻿namespace CustomerSupport.Modules {
    export interface LocationListRequest extends Serenity.ListRequest {
        LocationList?: number[];
    }
}

