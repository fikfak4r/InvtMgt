namespace CustomerSupport.BusinessObjects {
    export class GlobalScripts{

        public static Ticket_Read: string = "Customer Support:Ticket:Read";
        public static Ticket_Insert: string = "Customer Support:Ticket:Insert";
        public static Ticket_Update: string = "Customer Support:Ticket:Update";
        public static Ticket_Delete: string = "Customer Support:Ticket:Delete";

        public static Transaction_Read: string = "Customer Support:Transaction:Read";
        public static Transaction_Insert: string = "Customer Support:Transaction:Insert";
        public static Transaction_Update: string = "Customer Support:Transaction:Update";
        public static Transaction_Delete: string = "Customer Support:Transaction:Delete";

        public static Sms_Read: string = "Customer Support:Sms:Read";
        public static Sms_Insert: string = "Customer Support:Sms:Insert";
        public static Sms_Update: string = "Customer Support:Sms:Update";

        public static Customer_Read: string = "Customer Support:Customer:Read";
        public static Customer_Insert: string = "Customer Support:Customer:Insert";
        public static Customer_Update: string = "Customer Support:Customer:Update";
        public static Customer_Delete: string = "Customer Support:Customer:Delete";

        public static TicketId: number = 0;
        public static TransactionId: number = 0;
		public static CustomerId: number = 0;
    }
}