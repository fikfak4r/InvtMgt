﻿


namespace CustomerSupport.BusinessObjects.Pages
{
    using Serenity;
    using Serenity.Web;
    using System.Web.Mvc;
    using SMSLive247Api;


    [RoutePrefix("BusinessObjects/Sms"), Route("{action=index}")]
    public class SmsController : Controller
    {
        [PageAuthorize(BusinessObjects.PermissionKeys.Sms.Read)]
        public ActionResult Index()
        {
            return View("~/Modules/BusinessObjects/Sms/SmsIndex.cshtml");
        }


        [Route("SmsAccount")]
        //[PageAuthorize(Administration.PermissionKeys.ClientOfClient)]
        [PageAuthorize(Administration.PermissionKeys.Account)]
        public ActionResult SmsAccount()
        {
            string site_token = "02a66b0f-85ed-40e6-806e-cc669e821017";
            SMSSiteAdminClient SMS = new SMSLive247Api.SMSSiteAdminClient();
            SMSSiteInfo smsSiteInfo = new SMSLive247Api.SMSSiteInfo();


          
            ViewBag.CreditBalance = SMS.GetAccountInfo(site_token).CBalance;

            //var user = (UserDefinition)Authorization.UserDefinition;
            return View("~/Modules/BusinessObjects/Sms/SmsAccountOverview.cshtml");

        }


    }
}