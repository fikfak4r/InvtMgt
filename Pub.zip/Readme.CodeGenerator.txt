﻿This file is added here as NuGet packages has to provide some content.
You can safely delete this file.

To launch Serenity CodeGenerator, open 'Package Manager Console' 
(View -> Other Windows -> Package Manager Console) and type:

sergen