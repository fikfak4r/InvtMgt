﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryGn.Lib
{
    public class Class1
    {
        string str = "{int:avgBal1,int:avgBal2,date:startDate,date:endDate}";

    }
}
