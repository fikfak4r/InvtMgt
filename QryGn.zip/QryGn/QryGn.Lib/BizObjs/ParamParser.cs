﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryGn.Lib.BizObjs
{
    public class ParamParser
    {
        public static List<string> GetParamList(string param_s)
        {
            return param_s.Replace("{", "").Replace("}", "").Split(',').ToList<string>();
        }

        public static string GetDateType(string param)
        {
            return Split(param)[0] == "date" ? "DateTime": Split(param)[0];
        }

        public static string GetParamName(string param)
        {
            return Split(param)[1];
        }

        public static string GetParamValue(string param)
        {
            return Split(param)[2];
        }


        private static string[] Split(string param)
        {
            return param.Split(':');
        }



    }
}
