﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryGn.Lib.BizObjs
{
    public class StringClassCreator
    {

        private string param_s, runTimeTableName, templateName;
        public StringClassCreator(string templateName, string runTimeTableName, string param_s)
        {
            this.templateName = templateName;
            this.runTimeTableName = runTimeTableName;       
            this.param_s = param_s;
        }




        public string GetProperty(string param)
        {
            string property = String.Format(@"

            public {0} {1} [[ get; set; ]]

", ParamParser.GetDateType(param), ParamParser.GetParamName(param));
            return property;

        }//Ends GetProperty function




        public string GetClass()
        {
            String str = "";


            string properties = "";

            List<string> paramList = ParamParser.GetParamList(this.param_s);

            for(int x = 0; x < paramList.Count; x++)
            {
                properties += GetProperty(paramList[x]);
            }


            str = String.Format(@"

public class {0} [[

{1}


]]

", this.templateName, properties);


            return str;
        }


    }



}
