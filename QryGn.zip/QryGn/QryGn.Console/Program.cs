﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QryGn.Lib.BizObjs;


namespace QryGn.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            StringClassCreator scc = new StringClassCreator("AverageBalance", "Temp_AverageBalance", "{int:avgBal1,int:avgBal2,date:startDate,date:endDate}");

            System.Console.WriteLine(scc.GetClass());
            System.Console.ReadLine();
        }
    }
}
