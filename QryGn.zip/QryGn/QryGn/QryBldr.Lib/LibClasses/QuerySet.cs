﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryBldr.Lib.LibClasses
{
    public class QuerySet
    {

        public string Id { get; set; }
        public string ParentId { get; set; }
        public string Condition { get; set; }
        public string ItrnlCondtn { get; set; }
        public string TemplateName { get; set; }
        public string RunTimeTableName { get; set; }
        public string RunTimeTableName2 { get; set; }
        public List<QuerySet> QuerySetList { get; set; }
        public QryBlock QryBlock { get; set; }
        public string Value { get; set; }
        public string Clause { get; set; }
        public string Fields { get; set; }
        public List<QryField> SelectFields { get; set; }
        public bool IsImport { get; set; }
        public string Join { get; set; }
        public QryContainer Exclude { get; set; }
        public string GroupBy { get; set; }
        public string Qry { get; set; }
        public string ExcludeName { get; set; }
        public string ExcludeJoin { get; set; }

    }
}
