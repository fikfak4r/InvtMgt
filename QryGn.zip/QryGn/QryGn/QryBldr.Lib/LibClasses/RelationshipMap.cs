﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryBldr.Lib.LibClasses
{
    public class RelationshipMap
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public List<RelationshipMap> References {get; set;}

    }
}
