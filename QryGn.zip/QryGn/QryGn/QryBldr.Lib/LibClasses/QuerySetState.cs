﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryBldr.Lib.LibClasses
{
    public class QuerySetState
    {

        public int Count { get; set; }

        public int countTranversed { get; set; }

        public QuerySet ObjRef { get; set; }



    }
}
