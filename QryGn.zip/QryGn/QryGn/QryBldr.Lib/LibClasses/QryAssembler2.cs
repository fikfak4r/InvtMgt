﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QryBldr.Lib.LibClasses;


namespace QryBldr.Lib.LibClasses
{
    public class QryAssembler2 : QryAssembler
    {

        private QuerySet parent;
        private string qryString;
        private List<string> runTimeTables;
        private string andTemplateName;


        public static string RelatedKey = "CUST_ID";



        public QryAssembler2(QuerySet parent) : base(parent)
        {
            this.parent = parent;
        }


        List<QryField> externalSelectFieldsList, internalSelectFieldsList, selectFieldsList;
        public QryBox GetQryBox(List<QuerySet> children, QuerySet rootQs)
        {

            string _fields = rootQs.Fields;
            externalSelectFieldsList = new List<QryField>();
            internalSelectFieldsList = new List<QryField>();
            selectFieldsList = new List<QryField>();

            QryBox qb = new QryBox();

            if (this.parent.Condition == "Or")
            {

                string unionTemplateName = GetInLineTemplateName();

                string runTimeTable2Name = Utilities.AppendNumber(unionTemplateName);

                qb.Qry = OnOr(children, runTimeTable2Name, _fields, rootQs.SelectFields);


                if (!string.IsNullOrEmpty(qb.Qry))
                {

                    qb.HasQry = true;

                    if (runTimeTables.Count > 0)
                    {

                        string leftJoin = "";

                        for (int x = 0; x < this.runTimeTables.Count; x++)
                        {

                            //Get the joins
                            if(leftJoin == "")
                            {
                                leftJoin = LeftJoinPlain(runTimeTables[x], children[x].QryBlock.BaseQry.RltdColumns.Split(':')[1], unionTemplateName, RelatedKey);
                            }
                            else
                            {
                                leftJoin = string.Format("{0}{1}", leftJoin, LeftJoinPlain(runTimeTables[x], children[x].QryBlock.BaseQry.RltdColumns.Split(':')[1], unionTemplateName, RelatedKey));
                            }

                            string[] fullyQualifiedSplit = externalSelectFields.Split(',');
                 

                        }//Ends the big for loop
                        

                        qb.Qry += string.Format(@"
                                                    {0}

                                                     {1}
                                            ", 
                                            GetInMemoryTemplate(Union(this.runTimeTables), unionTemplateName),

                                            GetInMemoryTemplate(string.Format(@"SELECT {0} 
                                                    FROM {1} 
                                                    {2}", internalSelectFields, unionTemplateName, leftJoin), runTimeTable2Name)
                                            );


                        qb.TemplateName = runTimeTable2Name;

                    }

                    qb.Fields = externalSelectFields;

                }

            }
            else
            {

                andTemplateName = "";
                andTemplateName = GetInLineTemplateName();
                qb.Qry = OnAnd(children, _fields, rootQs.SelectFields, andTemplateName);

                if (!string.IsNullOrEmpty(qb.Qry))
                {
                    qb.HasQry = true;
                    qb.TemplateName = andTemplateName;
                    qb.Qry = GetInMemoryTemplate(qb.Qry, qb.TemplateName);
                    qb.Fields = externalSelectFields;
                    qb.SelectFields = selectFieldsList;
                }

            }

            return qb;

        }


        public string GetInMemoryTemplate(string qryBlockString, string runTimeTblName)
        {
            return string.Format(@"
    
                    CREATE VOLATILE TABLE  {0}  as(
    
                                {1}
    
                    )with data on commit preserve rows;


                    ", runTimeTblName, qryBlockString);



        }


        public string GetRunTimeTblNm(string runTimeTblNm)
        {

            string str = "";

            Func<string, bool> ff = (s) => { return s.StartsWith(runTimeTblNm); };

            string ss = runTimeTables.Where(ff).LastOrDefault();

            if (ss != null)
            {
                str = Utilities.AppendNumber(ss);
            }
            else
                str = runTimeTblNm;

            return str;

        }
     
        private string OnOr(List<QuerySet> children, string runTimeTableForConsolidate, string _fields, List<QryField> rootSelectFields)
        {

            qryString = "";


            externalSelectFields = "";
            externalFieldsRepository = "";


            string internalSelectFields_1 = "",
                   internalFieldsRepository_1 = "";




            runTimeTables = new List<string>();

            string runTimeTable = "";


            foreach (QuerySet qs in children)
            {



                internalSelectFields = "";
                //internalFieldsRepository = "";

                runTimeTable = GetRunTimeTblNm(GetInLineTemplateName());

                //AssembleInternalSelectFields(_fields, ref internalSelectFields, ref internalFieldsRepository, qs, "DD");
                ////Assembles for the Consolidate query block
                //AssembleInternalSelectFields(_fields, ref internalSelectFields_1, ref internalFieldsRepository_1, qs, runTimeTable);


                //AssembleExternalSelectFields(_fields, null, ref externalSelectFields, ref externalFieldsRepository, qs, runTimeTableForConsolidate);

                AssembleSelectFields(rootSelectFields, qs, runTimeTable);


                //if (!string.IsNullOrEmpty(externalFieldsRepository_1))
                //{

                //    externalFieldsRepository_1 = string.Format("{0},{1}", externalFieldsRepository_1, externalFieldsRepository);
                //}
                //else
                //    externalFieldsRepository_1 = string.Copy(externalFieldsRepository);



                if (qryString == "")
                {  

                    if (!string.IsNullOrEmpty(qs.RunTimeTableName2))
                    {
                        qryString = WrapSelectInto(qs.RunTimeTableName2, qs, runTimeTable);
                    }
                    else
                    {
                        qryString = WrapSelectInto(qs, runTimeTable);
                    }
                    
                }
                else
                {
                    string qryString2 = "";

                    if (!string.IsNullOrEmpty(qs.RunTimeTableName2))
                    {
                        qryString2 = WrapSelectInto(qs.RunTimeTableName2, qs, runTimeTable);
                    }
                    else
                    {
                        qryString2 = WrapSelectInto(qs, runTimeTable);
                    }



                    qryString += @"

                            --#-------------------------------------------------------#--

                        " + qryString2;

                    

                }


                runTimeTables.Add(runTimeTable);

            }//Ends the foreach block.

            internalSelectFields = string.Copy(internalSelectFields_1);

            return qryString;

        }

        public string OnAnd(List<QuerySet> children, string _fields, List<QryField> rootSelectFields, string runTimeTblNm)
        {

            qryString = "";
            internalSelectFields = "";
            externalSelectFields = "";
            int count = 0;
            string drvdTblNm = "";

            runTimeTables = new List<string>();

            foreach (QuerySet qs in children)
            {

                drvdTblNm = GetRunTimeTblNm(GetInLineTemplateName());

                if (qryString == "")
                {


                    //runTimeTable = GetRunTimeTblNm(qs.QryBlock.BaseQry.RunTimeTableName);
                    //AssembleInternalSelectFields(_fields, ref internalSelectFields, ref internalFieldsRepository, qs, runTimeTable);
                    //AssembleExternalSelectFields(_fields, rootSelectFields, ref externalSelectFields, ref externalFieldsRepository, qs, andTemplateName);
                    AssembleSelectFields(rootSelectFields, qs, drvdTblNm);

                    //fields = qs.QryBlock.BaseQry.Fields;
                    if (!string.IsNullOrEmpty(qs.RunTimeTableName2))
                        qryString = WrapSelect(qs.RunTimeTableName2, qs, drvdTblNm);
                    else
                        qryString = WrapSelect(qs, drvdTblNm);

                    //AssembleSelectFields(qs);


                }
                else
                {

                    if (IsDirectlyRelated(qs))
                    {


                        //runTimeTable = GetRunTimeTblNm(qs.QryBlock.BaseQry.RunTimeTableName);
                        //AssembleInternalSelectFields(_fields, ref internalSelectFields, ref internalFieldsRepository, qs, runTimeTable);
                        //AssembleExternalSelectFields(_fields, rootSelectFields, ref externalSelectFields, ref externalFieldsRepository, qs, andTemplateName);

                        AssembleSelectFields(rootSelectFields, qs, drvdTblNm);


                        if (!string.IsNullOrEmpty(qs.RunTimeTableName2))
                            qryString += InnerJoin(qs.RunTimeTableName2, qs, drvdTblNm);
                        else
                            qryString += InnerJoin(qs, drvdTblNm);

                        qryString += On(children[count - 1], qs, runTimeTables[runTimeTables.Count - 1], drvdTblNm);
                        //AssembleSelectFields(qs);

                    }
                    else
                    {

                        using (var contxt = new QryBldrDataModelEntities())
                        {

                            Func<BaseQryTemp, bool> getBaseQ = (s) => { return s.TemplateName == qs.TemplateName; };

                            BaseQryTemp baseQ = contxt.BaseQryTemps.Where(getBaseQ).FirstOrDefault();
                            
                            if (baseQ != null)
                            {

                                int parentId = Convert.ToInt32(baseQ.ParentId);
                                BaseQryTemp parentBaseQ = contxt.BaseQryTemps.Where((s) => s.BsId == parentId).FirstOrDefault();

                                QuerySet qs1 = new QuerySet() {};
                                
                                qs1.QryBlock = QuerySetParser.GetQryBlk(parentBaseQ.TemplateName, parentBaseQ.DfltVl, "");


                                //runTimeTable = GetRunTimeTblNm(qs.QryBlock.BaseQry.RunTimeTableName);
                                //AssembleInternalSelectFields(_fields, ref internalSelectFields, ref internalFieldsRepository, qs1, runTimeTable);
                                //AssembleExternalSelectFields(_fields, rootSelectFields, ref externalSelectFields, ref externalFieldsRepository, qs, andTemplateName);

                                AssembleSelectFields(rootSelectFields, qs, drvdTblNm);

                                qryString += InnerJoin(qs1, drvdTblNm);
                                qryString += On(children[count - 1], qs1, runTimeTables[runTimeTables.Count - 1], drvdTblNm);

                                //AssembleSelectFields(qs1);


                                //AssembleInternalSelectFields(_fields, ref internalSelectFields, ref internalFieldsRepository, qs, runTimeTable);
                                //AssembleExternalSelectFields(_fields, rootSelectFields, ref externalSelectFields, ref externalFieldsRepository, qs, andTemplateName);

                                AssembleSelectFields(rootSelectFields, qs, drvdTblNm);

                                qryString += InnerJoin(qs, drvdTblNm);
                                qryString += On(qs1, qs, runTimeTables[runTimeTables.Count - 1], drvdTblNm);
                                //AssembleSelectFields(qs);
                             


                            }


                        }//Ends the using block


                        //BridgeBuilder bd = new BridgeBuilder();
                        //bd.Build(children[count - 1], qs);

                        //QuerySetParser qsp = new QuerySetParser(bd.GetQuerySet());

                        //qryString += "|" + qsp.getTree();

                    }


                }//ends the big else block

                runTimeTables.Add(drvdTblNm);

                ++count;
               

            }//Ends the foreach

            qryString = (!string.IsNullOrEmpty(qryString)) ? string.Format(@"SELECT {0} 
                                                                                         
                                                                                           FROM 
                                                                                            {1}", 
                                                                                            QryField.GetInternalSelectFields(selectFieldsList), qryString) : "";


            return qryString;


        }

        public override string WrapSelect(string childTableName, QuerySet qs, string runTimeTable)
        {

            return string.Format(@"
                 (
            SELECT * FROM(
                              {0}
            )AS DD WHERE CUST_ID IN (SELECT CUST_ID FROM {1})

                    ) AS {2}
                    ",
                          (!string.IsNullOrEmpty(qs.ExcludeName)) ? ProcessExclude(qs) : qs.QryBlock.QryBlockString

                    , childTableName, runTimeTable);

        }

        public override string InnerJoin(QuerySet qs, string runTimeTable)
        {

            return string.Format(@"
                                    INNER JOIN (
                                            {0}
                                        ) AS {1}
                                    ", (!string.IsNullOrEmpty(qs.ExcludeName)) ? ProcessExclude(qs) : qs.QryBlock.QryBlockString, runTimeTable);

        }

        public override string InnerJoin(string childTableName, QuerySet qs, string runTimeTable)
        {

            return string.Format(@"
                                    INNER JOIN (
                                                    SELECT * FROM(
                                                                        {0}
                                                    )AS DD WHERE CUST_ID IN (SELECT CUST_ID FROM {1})
                                        ) AS {2}
                                    ", (!string.IsNullOrEmpty(qs.ExcludeName)) ? ProcessExclude(qs) : qs.QryBlock.QryBlockString, childTableName, runTimeTable);

        }

        public static string LeftJoinPlain(string leftTblNm,string leftTblField, string rightTblNm, string rightTblField)
        {
            return string.Format(@"
                                   LEFT JOIN {0}
                                  ON {2}.{3} = {0}.{1}", leftTblNm, leftTblField, rightTblNm, rightTblField);
        }

        public static string InnerJoinPlain(string leftTblNm, string leftTblField, string rightTblNm, string rightTblField)
        {
            return string.Format(@"
                                   INNER JOIN {0}
                                  ON {2}.{3} = {0}.{1}", leftTblNm, leftTblField, rightTblNm, rightTblField);
        }

        public override string WrapSelect(QuerySet qs, string runTimeTable)
        {

            return string.Format(@"
                    (
                                {0}
                    ) AS {1}
                    ",
                    (!string.IsNullOrEmpty(qs.ExcludeName)) ? ProcessExclude(qs) : qs.QryBlock.QryBlockString
                    , runTimeTable);
        }


        //public string ProcessFieldsNaming(string fieldsString)
        //{

        //    string[] strList = fieldsString.Split(',');

        //    foreach(string str in strList)
        //    {
        //        string[] strList2 = str.Split('.');
        //        string rtnString = GetDuplicateFieldName_ForInternalSelectFields(fieldsString, strList2[1]);

        //        if(rtnString != strList2[1])
        //        {
        //            fieldsString.Replace(str, string.Format("{0}.{1} AS {2}", strList2[0], strList2[1], Utilities.AppendNumber(rtnString)));

        //        }

        //    }


        //    return fieldsString;

        //}


        private string GetKey(QuerySet prevQs, QuerySet qs)
        {
            if (prevQs.QryBlock.BaseQry.ParentId == qs.QryBlock.BaseQry.BsId.ToString())
                return prevQs.QryBlock.BaseQry.RltdColumns;

            return qs.QryBlock.BaseQry.RltdColumns;
        }

        private string ProcessExclude(QuerySet qs)
        {
            return string.Format(@"
                                    SELECT * FROM ({0}) AS DD WHERE CUST_ID NOT IN (SELECT CUST_ID FROM {1})

                                    ", qs.QryBlock.QryBlockString, qs.ExcludeName);

        }


        private string On(QuerySet prevQs, QuerySet qs, string leftRunTimeTable, string rightRunTimeTable)
        {
            string key = GetKey(prevQs, qs);
            string[] keys = key.Split(':');

            //return string.Format(@"
            //                    ON {0}.{2} = {1}.{3}
            //                    ", prevQs.QryBlock.BaseQry.RunTimeTableName, qs.QryBlock.BaseQry.RunTimeTableName,
            //                   keys[0], keys[1]
            //                   );

            return string.Format(@"
                                ON {0}.{2} = {1}.{3}
                                ",  leftRunTimeTable, rightRunTimeTable,
                            !string.IsNullOrEmpty(prevQs.Join) ? prevQs.Join : keys[0],
                            !string.IsNullOrEmpty(qs.Join) ? qs.Join : keys[1]
                            );

        }

        private bool IsDirectlyRelated(QuerySet qs)
        {

            if (qs.QryBlock.BaseQry.RltdColumns.Split(':')[1] == QryAssembler2.RelatedKey)
                return true;

            return false;

        }

        


        public void AssembleSelectFields(List<QryField> rootSelectFields, QuerySet qs, string runTimeTableNm)
        {

            string[] fields = qs.QryBlock.BaseQry.Fields.Split(',');

            foreach (string fld in fields)
            {

                if (IsRequiredField(rootSelectFields, qs.TemplateName, fld))
                {
                    string rtnfldName = GetDuplicateFieldName(selectFieldsList, fld);

                    if (!string.IsNullOrEmpty(rtnfldName) && rtnfldName != fld)
                    {//This is got an alias
                        rtnfldName = Utilities.AppendNumber(rtnfldName);
                        QryField.AddField(selectFieldsList, runTimeTableNm, fld, rtnfldName);
                    }
                    else
                        QryField.AddField(selectFieldsList, runTimeTableNm, rtnfldName);
                }

            }//Ends the foreach

        }//Ends AssembleSelectFields

        string externalFieldsRepository = "";
        public void AssembleExternalSelectFields(string _fields, List<QryField> rootSelectFields, ref string _externalSelectFields, ref string _externalFieldsRepository, QuerySet qs, string runTimeTableNm)
        {
            
            string[] fields = qs.QryBlock.BaseQry.Fields.Split(',');

            foreach (string fld in fields)
            {

                if (IsRequiredField(rootSelectFields, qs.TemplateName, fld))
                {
                    string rtnfldName = GetDuplicateFieldName(externalSelectFieldsList, fld);

                    if (!string.IsNullOrEmpty(rtnfldName) && rtnfldName != fld)
                    {//This is got an alias
                        rtnfldName = Utilities.AppendNumber(rtnfldName);
                        QryField.AddField(externalSelectFieldsList, runTimeTableNm, fld, rtnfldName);
                    }
                    else
                        QryField.AddField(externalSelectFieldsList, runTimeTableNm, rtnfldName);
                }

            }//Ends the foreach

        }



        public bool IsRequiredField(List<QryField> rootSelectFields, string _templateName, string _field)
        {

            QryField qryField = rootSelectFields.FirstOrDefault((s) => { return string.Format("{0}.{1}", s.TemplateName, s.Name) == string.Format("{0}.{1}", _templateName, _field); });

            return (qryField != null || _field == RelatedKey) ? true : false;

        }

        public string GetDuplicateFieldName(List<QryField> selectFields, string fieldName)
        {

            string rtnFieldName = fieldName;

            QryField qryFld = selectFields.FirstOrDefault(s => s.Name == fieldName);

            if (qryFld != null)
                rtnFieldName = qryFld.Name + "_";


            List<int> myIntLst = new List<int>();

            IEnumerable<string> myAlias = selectFields.Select(s => QryField.GetName(s)).Where(x => {
                return x.StartsWith(rtnFieldName); 
            });

            if (myAlias != null)
            {
                myAlias.ToList().ForEach(y => {
                    List<char> charList = y.ToList();
                    myIntLst.Add((int)charList[charList.Count - 1]);
                });

                if (myIntLst.Count >= 1)
                {
                    int mx = myIntLst.Max();
                    rtnFieldName = fieldName + "_" + mx;
                }

            }

            return rtnFieldName;
        }

        public string GetDuplicateFieldName_ForExternalSelectFields(List<QryField> selectFields, string fieldName)
        {

            QryField qryFld = selectFields.FirstOrDefault(s => s.Name == fieldName);

            return (qryFld != null) ? qryFld.Name + "_" : fieldName;

        }



        public string WrapSelectBlock(string qryStr, string templateName)
        {

            return String.Format(@"
                    CREATE VOLATILE TABLE {0} AS (
                                      {1}
                    )ON COMMIT PRESERVE ROWS;
    
            ", templateName, qryStr);

        }

        public string GetInLineTemplateName()
        {
            //return "Temp_" + new Random(2000).Next(10000000);
             
            return string.Format("Temp_{0}_", DateTime.Now.Ticks);
        }

        public virtual string WrapSelectFull(QuerySet qs)
        {

            return string.Format(@"
                    SELECT * FROM (
                                {0}
                    ) AS {1}
                    ", qs.QryBlock.QryBlockString, qs.QryBlock.BaseQry.RunTimeTableName);
        }


        public virtual string WrapSelectInto(QuerySet qs, string runTimeTable)
        {

            return GetInMemoryTemplate((!string.IsNullOrEmpty(qs.ExcludeName)) ? ProcessExclude(qs) : qs.QryBlock.QryBlockString, runTimeTable);

            //return string.Format(@"
            //        SELECT * into {1} FROM (
            //                    {0}
            //        ) AS {1}
            //        ", qs.QryBlock.QryBlockString, qs.QryBlock.BaseQry.RunTimeTableName);
        }


        public virtual string WrapSelectInto(string childTableName, QuerySet qs, string runTimeTable)
        {
            
            string str = string.Format(@"
    
            SELECT {2} FROM(
                              {0}
            )AS DD WHERE CUST_ID IN (SELECT CUST_ID FROM {1})

                    
                    ",
                    (!string.IsNullOrEmpty(qs.ExcludeName)) ? ProcessExclude(qs) : qs.QryBlock.QryBlockString, 
                    childTableName, internalSelectFields);

            return GetInMemoryTemplate(str, runTimeTable);

        }


        public string Union(List<string> runTimeTables)
        {
            string union = "";

            foreach (string str in runTimeTables)
                if (union == "")
                {
                    union = "SELECT CUST_ID FROM " + str;
                }
                else
                {
                    union = string.Format(@"
                            {0}
                                   UNION

                            SELECT CUST_ID FROM {1}
", union, str);
                }


            return union;

        }


        //public string ConsolidateOr(List<string> runTimeTables)
        //{
        //    string str = "";

        //    Func<string, bool> ff = (s)  => { return true; };

        //    string[] fldLst = selectFields.Split(',').Where(;

        //    return str;
        //}



    }
}
