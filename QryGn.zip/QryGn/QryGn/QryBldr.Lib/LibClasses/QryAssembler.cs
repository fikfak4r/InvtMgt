﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryBldr.Lib.LibClasses
{
    public class QryAssembler
    {


        private QuerySet parent;
        private List<QuerySet> children;
        private string fields;
        private string qryString;
        public string internalSelectFields;
        public string externalSelectFields;


        public QryAssembler(QuerySet parent)
        {
            this.parent = parent;
        }


        int count = 0;
        public virtual string GetQryBlockString(List<QuerySet> children)
        {

            qryString = "";
            internalSelectFields = "";

            foreach (QuerySet qs in children)
            {


                if (qryString == "")
                {

                    fields = qs.QryBlock.BaseQry.Fields;
                    qryString = WrapSelect(qs, "Placeholder");
                    AssembleSelectFields(qs);

                }
                else
                {

                    if (IsDirectlyRelated(children[count - 1], qs))
                    {
                        qryString += InnerJoin(qs, "Placholder");
                        qryString += On(children[count - 1], qs);
                        AssembleSelectFields(qs);
                    }
                    else
                    {

                        BridgeBuilder bd = new BridgeBuilder();
                        bd.Build(children[count - 1], qs);

                        QuerySetParser qsp = new QuerySetParser(bd.GetQuerySet());

                        qryString += "|" + qsp.getTree();

                    }


                }//ends the big else block

                ++count;

            }//Ends the foreach

            qryString = (!string.IsNullOrEmpty(qryString)) ? string.Format(@"SELECT {0} FROM 
                                                                                            {1}", internalSelectFields, qryString) : "";
            return  qryString;

        }


        public virtual string WrapSelect(QuerySet qs, string runTimeTable)
        {
            
            return string.Format(@"
                    (
                                {0}
                    ) AS {1}
                    ", qs.QryBlock.QryBlockString, runTimeTable);
        }


        public virtual string WrapSelect(string childTableName, QuerySet qs, string runTimeTable)
        {

            return string.Format(@"
                 (
            SELECT * FROM(
                              {0}
            )AS DD WHERE CUST_ID IN (SELECT CUST_ID FROM {1})

                    ) AS {2}
                    ", qs.QryBlock.QryBlockString, childTableName, runTimeTable);

        }


        public virtual string InnerJoin(QuerySet qs, string runTimeTable)
        {

            return string.Format(@"
                                    INNER JOIN (
                                            {0}
                                        ) AS {1}
                                    ", qs.QryBlock.QryBlockString, runTimeTable);

        }

        public virtual string InnerJoin(string childTableName, QuerySet qs, string runTimeTable)
        {

            return string.Format(@"
                                    INNER JOIN (
                                                    SELECT * FROM(
                                                                        {0}
                                                    )AS DD WHERE CUST_ID IN (SELECT CUST_ID FROM {1})
                                        ) AS {2}
                                    ", qs.QryBlock.QryBlockString, childTableName, runTimeTable);

        }


        private void AssembleSelectFields(QuerySet qs)
        {
            string[] fields = qs.QryBlock.BaseQry.Fields.Split(',');

            foreach (string fld in fields)
                if (string.IsNullOrEmpty(internalSelectFields))
                {
                    internalSelectFields = string.Format("{0}.{1}", qs.QryBlock.BaseQry.RunTimeTableName, fld);
                }
                else
                {
                    internalSelectFields = string.Format(@"
                        {2},
                        {0}.{1}", qs.QryBlock.BaseQry.RunTimeTableName, fld, internalSelectFields);

                }

        }

        private string On(QuerySet prevQs, QuerySet qs)
        {
            string key = GetKey(prevQs, qs);
            string[] keys = key.Split(':');

            return string.Format(@"
                                ON {0}.{2} = {1}.{3}
                                ", prevQs.QryBlock.BaseQry.RunTimeTableName, qs.QryBlock.BaseQry.RunTimeTableName,
                               keys[0], keys[1]
                               );

        }


        private string GetKey(QuerySet prevQs, QuerySet qs)
        {
            if (prevQs.QryBlock.BaseQry.ParentId == qs.QryBlock.BaseQry.BsId.ToString())
                return prevQs.QryBlock.BaseQry.RltdColumns;

            return qs.QryBlock.BaseQry.RltdColumns;
        }


        private bool IsDirectlyRelated(QuerySet prevQs, QuerySet qs)
        {

            if (prevQs.QryBlock.BaseQry.ParentId == qs.QryBlock.BaseQry.BsId.ToString())
                return true;

            if (qs.QryBlock.BaseQry.ParentId == prevQs.QryBlock.BaseQry.BsId.ToString())
                return true;

            return false;

        }
    }
}
