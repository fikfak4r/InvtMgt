﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryBldr.Lib.LibClasses
{
    public class QryCase
    {

        public string Expression { get; set; }
        public string Value { get; set; }

    }

}
