﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Reflection;
using QryGn.Lib.BizObjs;
using System.CodeDom.Compiler;
using Microsoft.CSharp;
using System.IO;

namespace QryBldr.Lib.LibClasses
{
    public class QuerySetParser
    {

        QuerySet qs;
        Stack<QuerySetState> qssStack;
        int idCount = 0;
        Stack<QuerySet> qsStack;
        List<QuerySet> qsList;


        public static string ITRNL_CONDTN_EXCLUDE = "Exclude";
        


        public QuerySetParser(QuerySet qs)
        {

            this.qs = qs;
           
            qsStack = new Stack<QuerySet>();   
            qsList = new List<QuerySet>();     

            qssStack = new Stack<QuerySetState>();  
            
            SetNode(qs);

            tranverse(qssStack.Peek());

        }


        private string GetId()
        {
            return "Id" + ++idCount;
        }

        private void SetNode(QuerySet qs)
        {

            string id = GetId();
            qs.Id = id;
            qsStack.Push(qs);

            if(qs.QuerySetList != null)
                for(int x = 0; x < qs.QuerySetList.Count; x++)
                {
                    qs.QuerySetList[x].ParentId = id;
                    qsList.Add(qs.QuerySetList[x]);
                }
        
                qssStack.Push(new QuerySetState()
                {
                    Count = qs.QuerySetList.Count,
                    countTranversed = 0,
                    ObjRef = qs
                });
           
        }

        public void tranverse(QuerySetState qss)
        {

            //for(int x = 0; x < qss.ObjRef.QuerySetList.Count; x++)
            //{
            //if (qss.countTranversed < qss.ObjRef.QuerySetList.Count)
            if (qss.ObjRef.QuerySetList != null && qss.ObjRef.QuerySetList.Count >= 1 && qss.countTranversed < qss.Count)
            {

                if (qss.ObjRef.QuerySetList.Count >= 1)
                {

                    SetNode(qss.ObjRef.QuerySetList[qss.countTranversed]);

                    ++qss.countTranversed;

                    tranverse(this.qssStack.Peek());

                }//Ends the if block
                else
                {

                    //Here you have access to the QuerySet object
                    Console.WriteLine("Here: " + qss.ObjRef.QuerySetList[qss.countTranversed].TemplateName);
                    //++qss.countTranversed;

                }

            }
            else
            {
                //Console.WriteLine(qss.ObjRef.TemplateName);
            }

            if (qss.countTranversed < qss.Count)
                tranverse(qss);

            if (qss.countTranversed == qss.Count && this.qssStack.Count > 0)                      
                this.qssStack.Pop();


            if (this.qssStack.Count > 0)
                tranverse(this.qssStack.Peek());

            //}//Ends the for loop

        }



        public string getTree()
        {

            QryBlock qryBlock = null; int count = 0; 

            while (count < qsStack.Count)
            {

                QuerySet qs = qsStack.ElementAt(count);


                if (!qs.IsImport)
                    qryBlock = GetQryBlk(qs.TemplateName, qs.Value, qs.Clause); //Wrap(qs);
                else
                    qryBlock = GetQryBlkForImport(qs, qs.Value, qs.Clause);


                List<QuerySet> qsList = this.qsList.Where(xx => xx.ParentId == qs.Id).ToList();

                qs.QryBlock = qryBlock;


                QryAssembler2 qa = new QryAssembler2(qs);


                QryBox qb = new QryBox();

                if (qsList != null && qsList.Count > 0)
                {

                    qb = qa.GetQryBox(qsList, qsStack.ElementAt(qsStack.Count - 1));

                    if (qb.HasQry)
                    {

                        //qryBlock.BaseQry.Fields += qa.selectFields;

                        //qryBlock.QryBlockString = String.Format(@"{0} 
                        //                                                Un
                        //                                          {1}"
                        //, qryBlock.QryBlockString, subSet);

                        qs.RunTimeTableName2 = qb.TemplateName;
                        //qs.Fields += "," + qb.Fields;
                        qs.Fields = qb.Fields;
                        qryBlock.QryBlockString2 = String.Format(@"{0}", qb.Qry);
                        qs.SelectFields = qb.SelectFields;

                    }

                }

                if(qs.Exclude != null)
                {

                    QuerySetParser qsp = new QuerySetParser(qs.Exclude.Qs);
                    qsp.getTree();

                    QuerySet qSet = qsp.GetQSet();

                    qs.ExcludeName = qSet.RunTimeTableName;

                    qryBlock.QryBlockString2 += String.Format(@"
                                    ------------------------------ Exclude start ---------------------------------

                                                                   {0}
                              -----------------------------------------------------------------------------------------------
                                                                    {1}
                                    ------------------------------ Exclude ends ----------------------------------

                                                                ", qSet.Qry, qSet.RunTimeTableName);


                    //                    qryString += string.Format(@"
                    //                ------------------------------ Exclude start ---------------------------------
                    //                                {0}

                    //                                {1}

                    //                                {2}
                    //                ------------------------------ Exclude ends ----------------------------------
                    //", qSet.Qry, qSet.Fields, qs.RunTimeTableName);

                }


                qs.QryBlock = qryBlock;

                ++count;

            }//Ends the while loop


            return qs.QryBlock.QryBlockString2;

        }


        public QuerySet GetQSet()
        {
            string qList = "";


            int count = 0;
            string fields = "";


            while (count < qsStack.Count)
            {

                QuerySet qs = qsStack.ElementAt(count);

                //fields = qs.Fields;
                if (!string.IsNullOrEmpty(qs.QryBlock.QryBlockString2))
                {

                    if (qList == "")
                    {
                        qList = qs.QryBlock.QryBlockString2;
                        //qList += qs.Fields;
                        //qList += qs.RunTimeTableName2;

                    }
                    else
                    {
                        qList = String.Format(@"
                            {0}
                            -----------------------------------------------------------------------
                            {1}


                            ", qList, qs.QryBlock.QryBlockString2);
                    }

                }

                ++count;
            }//Ends the while loop

            LibClasses.Consolidate cons = new LibClasses.Consolidate(qsStack);
            QuerySet qsF = cons.GetQry();

            QuerySet qsFinal = new QuerySet();
            qsFinal.Qry = qList + qsF.Qry;
            qsFinal.Fields = qsF.Fields;
            qsFinal.RunTimeTableName = qsF.RunTimeTableName;


            return qsFinal;

        }


     

      public string GetInMemoryTemplate(QuerySet qs, string qryBlockString)
        {
            return string.Format(@"
    {2}
    CREATE VOLATILE TABLE  {0}  as(
    
    {1}
    
    )with data on commit preserve rows;


    ", qs.QryBlock.BaseQry.TemplateName, qryBlockString, qs.Condition);



        }


        public static QryBlock GetQryBlk(string templateName, string value, string clause)
        {

            BaseQryTemp bsQryTmp = new BaseQryTemp();
            List<DerivedQryTemp> drvQryTmpLst = new List<DerivedQryTemp>();



            List<String> drvdParams = new List<string>();
            List<String> qList = new List<string>();

            using (var contxt = new QryBldrDataModelEntities())
            {

                Func<BaseQryTemp, bool> getBaseQ = (s) => { return s.TemplateName == templateName; };

                BaseQryTemp baseQ = contxt.BaseQryTemps.Where(getBaseQ).FirstOrDefault();

                if (baseQ != null)
                {
                    bsQryTmp = baseQ;
                    drvQryTmpLst = baseQ.DerivedQryTemps.ToList();
                }


            }//Ends the using block

            foreach (DerivedQryTemp dQT in drvQryTmpLst)
            {

                drvdParams.Add(dQT.Params);
                qList.Add(dQT.QryTemplate);

            }//Ends the for loop


            StringClassCreator scc = new StringClassCreator(bsQryTmp.TemplateName, bsQryTmp.RunTimeTableName, bsQryTmp.Params);

            string classCode = Utilities.Format(scc.GetClass(bsQryTmp.Params, drvdParams, qList));

            
            using (var read = new System.IO.StreamWriter(AppDomain.CurrentDomain.BaseDirectory + @"\MyCode.txt", true))
            {
                read.Write(classCode);
            }


            CompilerResults compilerResults = CompileScript(classCode);

            if (compilerResults.Errors.HasErrors)
            {

                for (int y = 0; y < compilerResults.Errors.Count; y++)
                {
                    System.Console.WriteLine(compilerResults.Errors[y]);
                }

                System.Console.WriteLine("R");
                System.Console.ReadLine();

                throw new InvalidOperationException("Expression has a syntax error.");
            }

            Assembly assembly = compilerResults.CompiledAssembly;
            Type tt = assembly.GetType("QryGn.Lib." + templateName);
            object obj = Activator.CreateInstance(tt);

            object[] param_obj_list = ParamParser.ParseValues(bsQryTmp.Params, value);

            PropertyInfo[] properties = tt.GetProperties();

            for (int y = 0; y < properties.Length; y++)
            {
                properties[y].SetValue(obj, param_obj_list[y]);
            }
            

            MethodInfo method = tt.GetMethod("GetQ");


            string rtrndQ = (string)method.Invoke(obj, null);

            if(rtrndQ.Contains("@clause"))
            {
                return new QryBlock() { BaseQry = bsQryTmp, QryBlockString = rtrndQ = (!string.IsNullOrEmpty(clause)) ? string.Format("SELECT * FROM ({0}) AS DD", rtrndQ.Replace("@clause", " WHERE " + clause)) : rtrndQ.Replace("@clause", "") };
            }
            else
            {
                return new QryBlock() { BaseQry = bsQryTmp, QryBlockString = rtrndQ = (!string.IsNullOrEmpty(clause)) ? string.Format("SELECT * FROM ({0}) AS DD WHERE {1}", rtrndQ, clause) : rtrndQ };

            }


        }


        public static QryBlock GetQryBlkForImport(QuerySet qs, string value, string clause)
        {

            List<DerivedQryTemp> drvQryTmpLst = new List<DerivedQryTemp>();
            drvQryTmpLst.Add(new DerivedQryTemp()
            {
                Params = "{string:undefined:null}",
                QryTemplate = "SELECT * FROM Temp_" + qs.TemplateName,

            });

            BaseQryTemp bsQryTmp = new BaseQryTemp()
            {
                TemplateName = qs.TemplateName,
                Fields = qs.Fields,
                RunTimeTableName = "Temp_" + qs.TemplateName,
                Params = "{string:undefined}",
                RltdColumns = "CUST_ID:CUST_ID",
                DfltVl = "{}",
                DerivedQryTemps = drvQryTmpLst
            };
            



            List<String> drvdParams = new List<string>();
            List<String> qList = new List<string>();

        

            foreach (DerivedQryTemp dQT in drvQryTmpLst)
            {
                drvdParams.Add(dQT.Params);
                qList.Add(dQT.QryTemplate);
            }//Ends the for loop


            StringClassCreator scc = new StringClassCreator(bsQryTmp.TemplateName, bsQryTmp.RunTimeTableName, bsQryTmp.Params);

            string classCode = Utilities.Format(scc.GetClass(bsQryTmp.Params, drvdParams, qList));


            using (var read = new System.IO.StreamWriter(AppDomain.CurrentDomain.BaseDirectory + @"\MyCode.txt", true))
            {
                read.Write(classCode);
            }


            CompilerResults compilerResults = CompileScript(classCode);

            if (compilerResults.Errors.HasErrors)
            {

                for (int y = 0; y < compilerResults.Errors.Count; y++)
                {
                    System.Console.WriteLine(compilerResults.Errors[y]);
                }

                System.Console.WriteLine("R");
                System.Console.ReadLine();

                throw new InvalidOperationException("Expression has a syntax error.");
            }

            Assembly assembly = compilerResults.CompiledAssembly;
            Type tt = assembly.GetType("QryGn.Lib." + qs.TemplateName);
            object obj = Activator.CreateInstance(tt);

            object[] param_obj_list = ParamParser.ParseValues(bsQryTmp.Params, value);

            PropertyInfo[] properties = tt.GetProperties();

            for (int y = 0; y < properties.Length; y++)
            {
                properties[y].SetValue(obj, param_obj_list[y]);
            }


            MethodInfo method = tt.GetMethod("GetQ");


            string rtrndQ = (string)method.Invoke(obj, null);

            return new QryBlock() { BaseQry = bsQryTmp, QryBlockString = rtrndQ = (!string.IsNullOrEmpty(clause)) ? string.Format("SELECT * FROM ({0}) AS DD WHERE {1}", rtrndQ, clause) : rtrndQ };

        }

        public static CompilerResults CompileScript(string source)
        {

            CompilerParameters parms = new CompilerParameters();

            parms.GenerateExecutable = false;
            parms.GenerateInMemory = true;
            parms.IncludeDebugInformation = false;

            CodeDomProvider compiler = CSharpCodeProvider.CreateProvider("CSharp");

            return compiler.CompileAssemblyFromSource(parms, source);

        }



        //public void tranverse(QuerySetState qss)
        //{

        //    //for(int x = 0; x < qss.ObjRef.QuerySetList.Count; x++)
        //    //{
        //    //if (qss.countTranversed < qss.ObjRef.QuerySetList.Count)
        //    if (qss.ObjRef.QuerySetList != null && qss.ObjRef.QuerySetList.Count >= 1)
        //    {
        //        if (qss.ObjRef.QuerySetList[qss.countTranversed].QuerySetList.Count >= 1)
        //        {

        //            this.qss.Push(new QuerySetState()
        //            {
        //                Count = qss.ObjRef.QuerySetList[qss.countTranversed].QuerySetList.Count,
        //                countTranversed = 0,
        //                ObjRef = qss.ObjRef.QuerySetList[qss.countTranversed]
        //            });

        //            ++qss.countTranversed;

        //            tranverse(this.qss.Peek());

        //        }//Ends the if block
        //        else
        //        {

        //            //Here you have access to the QuerySet object
        //            Console.WriteLine(qss.ObjRef.QuerySetList[qss.countTranversed].TemplateName);
        //            ++qss.countTranversed;


        //        }
        //    }
        //    else
        //        Console.WriteLine(qss.ObjRef.TemplateName);


        //    if (qss.countTranversed < qss.Count)
        //        tranverse(qss);

        //    if (qss.countTranversed == qss.Count)
        //        this.qss.Pop();


        //    if (this.qss.Count > 0)
        //        tranverse(this.qss.Peek());

        //    //}//Ends the for loop

        //}


    }
}
