﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryBldr.Lib.LibClasses
{
    public class Consolidate
    {
        private Stack<QuerySet> qsStack;
        public Consolidate(Stack<QuerySet> qsStack)
        {
            this.qsStack = qsStack;
        }

        string selectFields = "", 
        privateSelectFields = "";

        public QuerySet GetQry()
        {
            QuerySet prevQrySet = null;

            QuerySet qs = qsStack.ElementAt(qsStack.Count - 1);

            AppendSelectFields_ForSelectFields(qs, qs.SelectFields);

            prevQrySet = qs;

            string joins = "";
            for (int x = qsStack.Count - 2; x >= 0; x--)
            {

                QuerySet qs1 = qsStack.ElementAt(x);

                if (qs1.SelectFields != null && qs1.SelectFields.Count >= 1)
                {

                    AppendSelectFields_ForSelectFields(qs1, qs1.SelectFields);
                

                        if (string.IsNullOrEmpty(joins))
                        {
                            joins = QryAssembler2.InnerJoinPlain(qs1.RunTimeTableName2, QryAssembler2.RelatedKey, prevQrySet.RunTimeTableName2, QryAssembler2.RelatedKey);
                        }
                        else
                        {
                            joins = string.Format(@"{0}
                                                {1}
                                                ", joins, QryAssembler2.InnerJoinPlain(qs1.RunTimeTableName2, QryAssembler2.RelatedKey, prevQrySet.RunTimeTableName2, QryAssembler2.RelatedKey));
                        }

                        prevQrySet = qs1;

                }//Ends the Big bang if block

            }//Ends the for loop

            string str = string.Format(@"

                            SELECT {0} FROM {1}
                             {2}

            ", selectFields, qs.RunTimeTableName2, joins);


            QuerySet qs2 = new QuerySet();
            qs2.Fields = selectFields;
            qs2.Qry = str;
            qs2.RunTimeTableName = qs.RunTimeTableName2;

            return qs2;

        }

        private void AppendSelectFields_ForSelectFields(QuerySet rootQrySet, List<QryField> qryFields)
        {

            if ((string.IsNullOrEmpty(selectFields)))
            {
                selectFields =  QryField.GetExternalSelectFields(rootQrySet.RunTimeTableName2, qryFields);
            }
            else
                selectFields = string.Format("{0},{1}", selectFields, QryField.GetExternalSelectFields(rootQrySet.RunTimeTableName2, qryFields));

        }


        //private bool AppendSelectFields(string runTimeTableName, string fields)
        //{
        //    bool rtnVal = false;

        //    if (!(string.IsNullOrEmpty(selectFields)))
        //    {
        //        string[] fieldList = privateSelectFields.Split(',');
        //        string[] fieldList_1 = StripRunTimeTableName(runTimeTableName, fields).Split(',');

        //        foreach (string field in fieldList_1)
        //        {
        //            string str = fieldList.FirstOrDefault((s) => { return s == field; });
        //            if(string.IsNullOrEmpty(str))
        //            {
        //                privateSelectFields = string.Format("{0},{1}", privateSelectFields, field);
        //                selectFields = string.Format("{0},{1}.{2}", selectFields, runTimeTableName, field);
        //                rtnVal = true;
        //            }
        //        }

        //    }
        //    else
        //    {
        //        privateSelectFields = StripRunTimeTableName(runTimeTableName, fields);
        //        selectFields = fields;
        //        rtnVal = true;
        //    }


        //    return rtnVal;
        //}//Ends the AppendSelectFields


        //public string StripRunTimeTableName(string runTimeTableName, string fields)
        //{
        //    return fields.Replace(runTimeTableName + ".", "");
        //}

    }
}
