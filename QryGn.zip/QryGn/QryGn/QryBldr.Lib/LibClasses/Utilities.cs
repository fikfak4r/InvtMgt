﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryBldr.Lib.LibClasses
{
    public class Utilities
    {

        public static string Format(string str)
        {
            return str.Replace("[[", "{").Replace("]]", "}");
        }


        public static string AppendNumber(string str)
        {

            string appendedNum = "";

            char[] lstxter = str.ToCharArray();

            int y = -1;
            string strVal = "";

            for(int x = (lstxter.Length - 1); x >= 0; x--)
            {

                try {
                    int ww = Convert.ToInt32(lstxter[x].ToString());
                    y = x;
                    strVal += lstxter[x];
                }
                catch { break; }
             


            }//Ends the for loop

            if (y == -1)
            {
                appendedNum = str + "1";
            }
            else
            {
                int z = Convert.ToInt32(strVal);
                z++;
                appendedNum = String.Format("{0}{1}", str.Replace(strVal, ""), z);
                //throw new Exception(appendedNum);
            }


            return appendedNum;

        }


        public static QryBlock GetParentQryBlock(string templateName)
        {

            using (var contxt = new QryBldrDataModelEntities())
            {

                Func<BaseQryTemp, bool> getBaseQ = (s) => { return s.TemplateName == templateName; };

                BaseQryTemp baseQ = contxt.BaseQryTemps.Where(getBaseQ).FirstOrDefault();

                if (baseQ != null)
                {

                    int parentId = Convert.ToInt32(baseQ.ParentId);
                    BaseQryTemp parentBaseQ = contxt.BaseQryTemps.Where((s) => s.BsId == parentId).FirstOrDefault();


                    return QuerySetParser.GetQryBlk(parentBaseQ.TemplateName, parentBaseQ.DfltVl, "");

                }


            }//Ends the using block


            return null;

        }

    }


}
