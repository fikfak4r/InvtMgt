﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;


namespace QryBldr.Lib.LibClasses
{
    public class BridgeBuilder
    {

        RelationshipMap rm;
        Stack<RelationshipMapState> rmsStack;
        int idCount = 0;
        Stack<RelationshipMap> rmStack;
        List<RelationshipMap> qsList;



        public RelationshipMap GetMap()
        {

            RelationshipMap rm = new RelationshipMap();

            JsonSerializer serializer = new JsonSerializer();

            using (StreamReader sr = new StreamReader(String.Format(@"{0}\MapFile.txt", AppDomain.CurrentDomain.BaseDirectory)))
            using (JsonReader reader = new JsonTextReader(sr))
            {

                 rm =  serializer.Deserialize<RelationshipMap>(reader);

            }

            return rm;
        }

        private QuerySet qs1, qs2, qs;
        public void Build(QuerySet qs1, QuerySet qs2)
        {

            this.qs1 = qs1;
            this.qs2 = qs2;
            
            this.qs = new QuerySet() { Id = "5", TemplateName = "Root", QuerySetList = new List<QuerySet>(), Value = "{}", Condition = "and" };

            rmStack = new Stack<RelationshipMap>();
            qsList = new List<RelationshipMap>();

            rmsStack = new Stack<RelationshipMapState>();


            RelationshipMap rm = GetMap();

            this.rm = rm;

            SetNode(rm);

            tranverse(rmsStack.Peek());


        }

        public QuerySet GetQuerySet()
        {
            return this.qs;
          
        }

        public void tranverse(RelationshipMapState rms)
        {

            if (!IsFound())
            {

                if (rms.ObjRef.References != null && rms.ObjRef.References.Count >= 1 && rms.countTranversed < rms.Count)
                {

                    if (rms.ObjRef.References.Count >= 1)
                    {

                        SetNode(rms.ObjRef.References[rms.countTranversed]);

                        ++rms.countTranversed;

                        tranverse(this.rmsStack.Peek());

                    }//Ends the if block
                    else
                    {

                        //Here you have access to the RelationshipMap object
                        Console.WriteLine("Here: " + rms.ObjRef.References[rms.countTranversed].Name);
                        //++rms.countTranversed;


                    }

                }
                else
                {
                    //Console.WriteLine(rms.ObjRef.TemplateName);
                }

                if (rms.countTranversed < rms.Count)
                    tranverse(rms);

                if (rms.countTranversed == rms.Count && this.rmsStack.Count > 0)
                {
                    this.rmsStack.Pop();
                    this.rmStack.Pop();
                }

                if (this.rmsStack.Count > 0)
                    tranverse(this.rmsStack.Peek());

            }//Ends IsFound block
            else
            {
                

                for (int x = rmStack.Count - 1; x >= 0; x--)
                {

                    if (this.qs1.QryBlock.BaseQry.BsId == rmStack.ElementAt(x).Id)
                    {
                        

                        AppendQuerySet(this.qs, GetQuerySet(rmStack.ElementAt(x)));

                        for (int y = x - 1; y >= 0; y--)
                        {

                            AppendQuerySet(this.qs, GetQuerySet(rmStack.ElementAt(y)));

                            if (this.qs2.QryBlock.BaseQry.BsId == rmStack.ElementAt(y).Id)
                                break;

                        }//End the inner for loop

                        break;
                    }

                }//Ends the for loop

            }//Ends the else block

        }

        private QuerySet GetQuerySet(RelationshipMap rmState)
        {
            return new QuerySet()
            {
                Id = rmState.Id.ToString(),
                TemplateName = rmState.Name,
                QuerySetList = new List<QuerySet>(),
                Value = rmState.Value


            };
        }


        private void AppendQuerySet(QuerySet parentQs, QuerySet qs)
        {
            parentQs.QuerySetList.Add(qs);

            //if (this.qs != null)
            //{
            //    if (parentQs.QuerySetList.Count >= 1)
            //    {
            //        AppendQuerySet(parentQs.QuerySetList[0], qs);
            //    }
            //    else {

                   

            //    }
            //}
          

        }

        private void SetNode(RelationshipMap qs)
        {
           
            rmStack.Push(qs);

            //if (qs.References != null)
            //    for (int x = 0; x < qs.References.Count; x++)
            //    {
            //        //qs.References[x].ParentId = id;
            //        qsList.Add(qs.References[x]);
            //    }

            rmsStack.Push(new RelationshipMapState()
            {
                Count = qs.References.Count,
                countTranversed = 0,
                ObjRef = qs

            });

        }

        private bool IsFound()
        {
            bool isLeftFound = false, isRightFound = false;

            foreach(RelationshipMap rm in rmStack)
            {
                if(rm.Id == this.qs1.QryBlock.BaseQry.BsId)
                {
                    isLeftFound = true;
                    break;
                }
            }

            foreach (RelationshipMap rm in rmStack)
            {
                if (rm.Id == this.qs2.QryBlock.BaseQry.BsId)
                {
                    isRightFound = true;
                    break;
                }
            }


            return isLeftFound & isRightFound;


        }

    }


    public class RelationshipMapState
    {

        public int Count { get; set; }

        public int countTranversed { get; set; }

        public RelationshipMap ObjRef { get; set; }



    }



}
