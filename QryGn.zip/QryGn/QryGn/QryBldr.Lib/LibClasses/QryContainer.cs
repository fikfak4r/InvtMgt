﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryBldr.Lib.LibClasses
{
    public class QryContainer
    {

        public string Id { get; set; }
        public string Fields { get; set; } 
        public string ParentId { get; set; }
        public QuerySet Qs { get; set; }
        public List<QryContainer> QryContainerList { get; set; }
    }
}
