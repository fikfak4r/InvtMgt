﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryBldr.Lib.LibClasses
{
    public class ContainerParser
    {


        QryContainer qc;
        Stack<QryContainerState> qcsStack;
        int idCount = 0;
        Stack<QryContainer> qcStack;
        List<QryContainer> qcList;





        public ContainerParser(QryContainer qc)
        {

            this.qc = qc;

            qcStack = new Stack<QryContainer>();
            qcList = new List<QryContainer>();

            qcsStack = new Stack<QryContainerState>();

            SetNode(qc);

            tranverse(qcsStack.Peek());

        }


        private string GetId()
        {
            return "Id" + ++idCount;
        }

        private void SetNode(QryContainer qc)
        {

            string id = GetId();
            qc.Id = id;
            qcStack.Push(qc);

            if (qc.QryContainerList != null)
                for (int x = 0; x < qc.QryContainerList.Count; x++)
                {
                    qc.QryContainerList[x].ParentId = id;
                    qcList.Add(qc.QryContainerList[x]);
                }

            qcsStack.Push(new QryContainerState()
            {
                Count = qc.QryContainerList.Count,
                countTranversed = 0,
                ObjRef = qc
            });

        }

        public void tranverse(QryContainerState qcs)
        {

            //for(int x = 0; x < qcs.ObjRef.QryContainerList.Count; x++)
            //{
            //if (qcs.countTranversed < qcs.ObjRef.QryContainerList.Count)
            if (qcs.ObjRef.QryContainerList != null && qcs.ObjRef.QryContainerList.Count >= 1 && qcs.countTranversed < qcs.Count)
            {

                if (qcs.ObjRef.QryContainerList.Count >= 1)
                {

                    SetNode(qcs.ObjRef.QryContainerList[qcs.countTranversed]);

                    ++qcs.countTranversed;

                    tranverse(this.qcsStack.Peek());

                }//Ends the if block
                else
                {

                    //Here you have access to the QryContainer object
                    //Console.WriteLine("Here: " + qcs.ObjRef.QryContainerList[qcs.countTranversed].TemplateName);
                    //++qcs.countTranversed;

                }

            }
            else
            {
                //Console.WriteLine(qcs.ObjRef.TemplateName);
            }

            if (qcs.countTranversed < qcs.Count)
                tranverse(qcs);

            if (qcs.countTranversed == qcs.Count && this.qcsStack.Count > 0)
                this.qcsStack.Pop();


            if (this.qcsStack.Count > 0)
                tranverse(this.qcsStack.Peek());

            //}//Ends the for loop

        }




    }
}
