﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 

namespace QryBldr.Lib.LibClasses
{
    public class QryBlock
    {
        public BaseQryTemp BaseQry { get; set; }
        public string QryBlockString { get; set; }
        public string QryBlockString2 { get; set; }

        public string Alias { get; set; }

    }
}
