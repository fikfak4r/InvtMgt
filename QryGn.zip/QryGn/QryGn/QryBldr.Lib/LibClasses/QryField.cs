﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryBldr.Lib.LibClasses
{
    public class QryField
    {
        public string Name { get; set; }
        public string Alias { get; set; }
        public List<QryCase> Case { get; set; }
        public string RunTimeTableName { get; set; }
        public string TemplateName { get; set; }

        public static string GetName(QryField qryField)
        {
            return (!string.IsNullOrEmpty(qryField.Alias)) ? qryField.Alias : qryField.Name;
        }

        public static string GetNamesListStringified(List<QryField> qryFields)
        {
            return qryFields.Select(s => s.Name).ToArray().Aggregate((v1, v2) => String.Format("{0},{1}", v1, v2));
        }

        public static string GetFullNamesListStringified(List<QryField> qryFields)
        {
            return qryFields.Select(s => new { FullName = String.Format("{0}.{1}", s.RunTimeTableName, s.Name) }.FullName.ToString()).ToArray().Aggregate((v1, v2) => String.Format("{0},{1}", v1, v2));
        }

        public static void AddField(List<QryField> qryFields, string runTimeTableName, string name)
        {
            qryFields.Add(new QryField() { Name = name, RunTimeTableName = runTimeTableName });
        }

        public static void AddField(List<QryField> qryFields, string runTimeTableName, string name, string alias)
        {
            qryFields.Add(new QryField() { Name = name, RunTimeTableName = runTimeTableName, Alias = alias });
        }

        public static string GetInternalSelectFields(List<QryField> qryFields)
        {
            return qryFields.Select(s => new { FullName = GetInternalSelectAlias(s) }.FullName.ToString()).ToArray().Aggregate((v1, v2) => String.Format("{0},{1}", v1, v2));
        }

        private static string GetInternalSelectAlias(QryField qryField)
        {
            return (!string.IsNullOrEmpty(qryField.Alias)) ? String.Format("{0}.{1} AS {2}", qryField.RunTimeTableName, qryField.Name, qryField.Alias) : String.Format("{0}.{1}", qryField.RunTimeTableName, qryField.Name);
        }

        public static string GetExternalSelectFields(string runTimeTableName, List<QryField> qryFields)
        {
            return qryFields.Select(s => new { FullName = String.Format("{0}.{1}", runTimeTableName, GetName(s)) }.FullName.ToString()).ToArray().Aggregate((v1, v2) => String.Format("{0},{1}", v1, v2));
        }

    }
}
