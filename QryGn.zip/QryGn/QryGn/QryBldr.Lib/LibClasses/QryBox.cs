﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryBldr.Lib.LibClasses
{
    public class QryBox
    {
        public string Qry { get; set; }

        public string TemplateName { get; set; }

        public bool HasQry { get; set; }

        public string Fields { get; set; }

        public List<QryField> SelectFields { get; set; }

    }
}
