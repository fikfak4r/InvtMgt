﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using QryGn.Lib.BizObjs;
using System.CodeDom.Compiler;
using Microsoft.CSharp;
using System.IO;
using Newtonsoft.Json;
using QryBldr.Lib.LibClasses;
using consl = System.Console;
using QryBldr.Lib;

namespace QryGn.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            //Execute1();


          

            JsonSerializer serializer = new JsonSerializer();

            //Clear the file
            using (var read = new System.IO.StreamWriter(AppDomain.CurrentDomain.BaseDirectory + @"\MyCode.txt"))
            {
                read.Write("");
            }


            using (StreamReader sr = new StreamReader(String.Format(@"{0}\json.json", AppDomain.CurrentDomain.BaseDirectory)))
            using (JsonReader reader = new JsonTextReader(sr))
            {

                QryContainer qs = serializer.Deserialize<QryContainer>(reader);

                //consl.WriteLine("Product: {0}", qs.QuerySetList[1].RunTimeTableName);
                QuerySetParser qsp = new QuerySetParser(qs.Qs);
                consl.WriteLine("------------------------");
                qsp.getTree();

                QuerySet qsFinal = qsp.GetQSet();

                File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "output.txt", qsFinal.Qry +
                    @"

                                                       
                        " + qsFinal.Fields
                    
                    );



                //consl.Read();

            }



        }

        //private static void Execute1()
        //{

        //    //string request = "{RetailCustomer::{}^^or^^AverageBalance::{20|^|^2019-01-02 00:00:00|^}}";
        //    string request = "{RetailCustomer::{}^^or^^CONSC(AverageBalance::{20|^|^2019-01-02 00:00:00|^}}, MM, 3)^^EXCLUDE(KidsAccounts::{})";
        //    //string request = "{AverageBalance:{|^|^2019-01-02 00:00:00|^}}";

        //    string[] requestList = RequestParser.ParseRequest(request);

        //    string templateName = "AverageBalance";
        //    string baseParam = "", runTimeTableName = "";
        //    //string values = "{20|^|^2019-01-02 00:00:00|^}";

        //    Dictionary<BaseQryTemp, List<DerivedQryTemp>> baseDrvdAQryTempList = new Dictionary<BaseQryTemp, List<DerivedQryTemp>>();
        //    List<string> values = new List<string>();

        //    using (var contxt = new StagingEntities())
        //    {

        //        for (int x = 0; x < requestList.Length; x++)
        //        {

        //            Func<BaseQryTemp, bool> getBaseQ = (s) => { return s.TemplateName == RequestParser.GetTemplateName(requestList[x]); };

        //            BaseQryTemp baseQ = contxt.BaseQryTemps.Where(getBaseQ).FirstOrDefault();

        //            if (baseQ != null)
        //            {
        //                baseDrvdAQryTempList.Add(baseQ, baseQ.DerivedQryTemps.ToList());
        //                values.Add(RequestParser.GetValueString(requestList[x]));
        //            }


        //        }//Ends the for loop


        //    }//

        //    Dictionary<string, string> drvdQryList = new Dictionary<string, string>();

        //    for (int x = 0; x < baseDrvdAQryTempList.Count; x++)
        //    {

        //        templateName = baseDrvdAQryTempList.ElementAt(x).Key.TemplateName;
        //        runTimeTableName = baseDrvdAQryTempList.ElementAt(x).Key.RunTimeTableName;
        //        baseParam = baseDrvdAQryTempList.ElementAt(x).Key.Params;

        //        List<String> drvdParams = new List<string>();
        //        List<String> qList = new List<string>();


        //        foreach (DerivedQryTemp dQT in baseDrvdAQryTempList.ElementAt(x).Value)
        //        {
        //            drvdParams.Add(dQT.Params);
        //            qList.Add(dQT.QryTemplate);
        //        }//Ends the for loop



        //        StringClassCreator scc = new StringClassCreator(templateName, runTimeTableName, baseParam);

        //        string classCode = Utilities.Format(scc.GetClass(baseParam, drvdParams, qList));

        //        using (var read = new System.IO.StreamWriter(AppDomain.CurrentDomain.BaseDirectory + @"\MyCode.txt"))
        //        {
        //            read.Write(classCode);
        //        }

        //        //System.Console.WriteLine(classCode);
        //        //System.Console.ReadLine(); 

        //        CompilerResults compilerResults = CompileScript(classCode);



        //        if (compilerResults.Errors.HasErrors)
        //        {

        //            for (int y = 0; y < compilerResults.Errors.Count; y++)
        //            {
        //                System.Console.WriteLine(compilerResults.Errors[y]);
        //            }

        //            System.Console.WriteLine("R");
        //            System.Console.ReadLine();

        //            throw new InvalidOperationException("Expression has a syntax error.");
        //        }

        //        Assembly assembly = compilerResults.CompiledAssembly;
        //        Type tt = assembly.GetType("QryGn.Lib." + templateName);
        //        object obj = Activator.CreateInstance(tt);

        //        //PropertyInfo prop = tt.GetProperty("avgBal1");
        //        //prop.SetValue(obj, 20);

        //        //PropertyInfo prop1 = tt.GetProperty("startDate");
        //        //prop1.SetValue(obj, DateTime.Today);

        //        //var authorAnonymousType = new
        //        //{
        //        //    avgBalOne = String.Empty,
        //        //    avgBalTwo = false,
        //        //    startDate = DateTime.Today,
        //        //    endDate = DateTime.Today
        //        //};


        //        //JsonConvert.DeserializeAnonymousType(jsonRqst, authorAnonymousType);
        //        //JsonConvert.DeserializeAnonymousType(jsonRqst, obj); 

        //        object[] param_obj_list = ParamParser.ParseValues(baseParam, values[x]);

        //        PropertyInfo[] properties = tt.GetProperties();

        //        for (int y = 0; y < properties.Length; y++)
        //        {
        //            properties[y].SetValue(obj, param_obj_list[y]);
        //        }

        //        //MethodInfo mthd = tt.GetMethod("SetVals");
        //        //mthd.Invoke(obj, param_obj_list);

        //        MethodInfo method = tt.GetMethod("GetQ");


        //        string rtrndQ = (string)method.Invoke(obj, null);

        //        //object jsonDesObj = JsonConvert.DeserializeObject(jsonRqst);

        //        drvdQryList.Add(templateName, rtrndQ);



        //    }//Ends the big for loop

        //    for (int x = 0; x < drvdQryList.Count; x++)
        //        System.Console.WriteLine(String.Format("{0}: {1}", drvdQryList.ElementAt(x).Key, drvdQryList.ElementAt(x).Value));






        //        System.Console.ReadLine();
        //}






        public static CompilerResults CompileScript(string source)
        {

            CompilerParameters parms = new CompilerParameters();

            parms.GenerateExecutable = false;
            parms.GenerateInMemory = true;
            parms.IncludeDebugInformation = false;

            CodeDomProvider compiler = CSharpCodeProvider.CreateProvider("CSharp");

            return compiler.CompileAssemblyFromSource(parms, source);

        }




    }

}
