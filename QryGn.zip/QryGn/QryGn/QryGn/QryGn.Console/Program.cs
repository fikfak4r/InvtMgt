﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using QryGn.Lib.BizObjs;
using System.CodeDom.Compiler;
using Microsoft.CSharp;
using System.IO;
using Newtonsoft.Json;


namespace QryGn.Console
{
    class Program
    {
        static void Main(string[] args)
        {

            string templateName = "AverageBalance";
            String jsonRqst = @"{'avgBalOne':20,'avgBalTwo':40,'startDate':'2019-01-02 00:00:00','endDate':'2019-01-03 00:00:00'}";

            StringClassCreator scc = new StringClassCreator(templateName, "Temp_AverageBalance", "{int:avgBal1,int:avgBal2,date:startDate,date:endDate}");

            

            List<String> drvdParams = new List<string>
            {
                "{double:avgBal1:not_null,double:avgBal2:null,date:startDate:not_null,date:endDate:null}"
            };

            List<String> qList = new List<string>
            {
                "Select * from AccountSummaryDemand"
            };


            string classCode = Utilities.Format(scc.GetClass(drvdParams, qList));

            using (var read = new System.IO.StreamWriter(@"C:\Users\Fikayo.Aboluwarin\Downloads\QryGn\QryGn\MyCode.txt"))
            {
                read.Write(classCode);
            }

            //System.Console.WriteLine(classCode);
            //System.Console.ReadLine();

            CompilerResults compilerResults = CompileScript(classCode);



            if (compilerResults.Errors.HasErrors)
            {

                for (int x = 0; x < compilerResults.Errors.Count; x++) {
                    System.Console.WriteLine(compilerResults.Errors[x]);
                }
                System.Console.WriteLine("R");
                System.Console.ReadLine();
                throw new InvalidOperationException("Expression has a syntax error.");
            }

            Assembly assembly = compilerResults.CompiledAssembly;
            Type tt = assembly.GetType("QryGn.Lib." + templateName);
            object obj = Activator.CreateInstance(tt);

            PropertyInfo prop = tt.GetProperty("avgBal1");
            prop.SetValue(obj, 20);

            PropertyInfo prop1 = tt.GetProperty("startDate");
            prop1.SetValue(obj, DateTime.Today);

            var authorAnonymousType = new
            {
                avgBalOne = String.Empty,
                avgBalTwo = false,
                startDate = DateTime.Today,
                endDate = DateTime.Today
            };


            //JsonConvert.DeserializeAnonymousType(jsonRqst, authorAnonymousType);
            JsonConvert.DeserializeAnonymousType(jsonRqst, obj);

            MethodInfo method = tt.GetMethod("GetQ");


            string rtrndQ = (string)method.Invoke(obj, null);

            //object jsonDesObj = JsonConvert.DeserializeObject(jsonRqst);


            //System.Console.WriteLine(tt.GetProperty("avgBal1").GetValue(obj));
            System.Console.WriteLine("tt: " + tt.GetProperty("startDate").GetValue(obj));
            System.Console.WriteLine(authorAnonymousType.avgBalOne);
            System.Console.WriteLine(authorAnonymousType.startDate);
            System.Console.WriteLine(rtrndQ);
            System.Console.ReadLine();

        }





        public static CompilerResults CompileScript(string source)
        {

            CompilerParameters parms = new CompilerParameters();

            parms.GenerateExecutable = false;
            parms.GenerateInMemory = true;
            parms.IncludeDebugInformation = false;

            CodeDomProvider compiler = CSharpCodeProvider.CreateProvider("CSharp");

            return compiler.CompileAssemblyFromSource(parms, source);

        }




    }

}
