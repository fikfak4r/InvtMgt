﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryGn.Lib.BizObjs
{
    public class StringClassCreator
    {


        private string baseParams, runTimeTableName, templateName;
        public StringClassCreator(string templateName, string runTimeTableName, string baseParams)
        {
            this.templateName = templateName;
            this.runTimeTableName = runTimeTableName;       
            this.baseParams = baseParams;
        }

        //
        //{
        //double:avgBal1:not_null,
        //double:avgBal2:null,
        //date:startDate:not_null,
        //date:endDate:null
        //}


        public string BuildMethod(List<string> drvdParams, List<string> qList)
        {
            string cntrlStructure = "";

            for (int x = 0; x < drvdParams.Count; x++)
            {

                string expression = "";

                List<string> paramList = ParamParser.GetParamList(drvdParams[x]);

                for(int y = 0; y < paramList.Count; y++)
                {
                    if (String.IsNullOrEmpty(expression)){
                        expression = String.Format("{0}{1}", ParamParser.GetParamName(paramList[y]), GetAssignmentSnipnet(ParamParser.GetParamValue(paramList[y])));
                    }
                    else
                    {
                        expression = String.Format("{0} && {1}{2}", expression, ParamParser.GetParamName(paramList[y]), GetAssignmentSnipnet(ParamParser.GetParamValue(paramList[y])));

                    }
                }//Ends the inner Loop


                if(String.IsNullOrEmpty(cntrlStructure))
                {
                        cntrlStructure = String.Format(@"if({0})
                    [[
                        q = ""{1}"";
                    ]]

                    ", expression, qList[x]);
                }
                else
                {
                    cntrlStructure = String.Format(@"{0}
                        else({1})
                        [[
                             q = ""{2}"";
                        ]]
                        ", cntrlStructure, expression, qList[x]);
                }


            }//Ends the outer for loop


            return cntrlStructure;

        }

        private string GetAssignmentSnipnet(string drvdParamValue)
        {
            return drvdParamValue == "not_null" ? " != null" : " == null";
        }



        public string GetProperty(string param)
        {
            string property = String.Format(@"public {0}? {1} [[ get; set; ]]", ParamParser.GetDateType(param), ParamParser.GetParamName(param));
            return property;

        }//Ends GetProperty function




        public string GetClass(List<string> drvdParams, List<string> qList)
        {
            String str = "";


            string properties = "";

            List<string> paramList = ParamParser.GetParamList(this.baseParams);

            for(int x = 0; x < paramList.Count; x++)
            {
                properties += GetProperty(paramList[x]);
            }


            str = String.Format(@"namespace QryGn.Lib[[ using System; public class {0} [[ {1} 
public string GetQ()[[ string q = ""Qry""; 
{2}
return q; ]] ]] ]]", 
this.templateName, properties, BuildMethod(drvdParams, qList)
);


            return str;
        }


    }



}
