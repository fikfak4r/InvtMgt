﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryGn.Lib
{

    

    public class AverageBalance { public int avgBal1 { get; set; } public int avgBal2 { get; set; } public DateTime startDate { get; set; } public DateTime endDate { get; set; } public string GetQ() { string q = ""; return q; } }



}
