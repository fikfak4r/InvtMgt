﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryGn.Lib.BizObjs
{
    public class RequestParser
    {
        public static string[] ParseRequest(string requestString)
        {
            requestString = requestString.Replace("{", "").Replace("}", "");
            string[] values_list = requestString.Split(new string[] { "^^" }, StringSplitOptions.None);
            return values_list;
        }

        public static string GetTemplateName(string requestVal)
        {

            return requestVal.Split(new string[] { ":" }, StringSplitOptions.None)[0];

        }

        public static string GetValueString(string requestVal)
        {

            return requestVal.Split(new string[] { "::" }, StringSplitOptions.None)[1];

        }


    }
}
