﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryGn.Lib.BizObjs
{
    public static class TypeConverter
    {
        public static Int32 ToInteger(string val)
        {
            return Convert.ToInt32(val);
        }

        public static Decimal ToDecimal(string val)
        {
            return Convert.ToDecimal(val);
        }

        public static DateTime ToDateTime(string val)
        {
            return Convert.ToDateTime(val);
        }
    }
}
