﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryGn.Lib.BizObjs
{
    public class Utilities
    {

        public static string Format(string str)
        {
            return str.Replace("[[", "{").Replace("]]", "}");
        }

    }
}
