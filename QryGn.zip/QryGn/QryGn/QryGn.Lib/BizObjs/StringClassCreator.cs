﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryGn.Lib.BizObjs
{
    public class StringClassCreator
    {


        private string baseParams, runTimeTableName, templateName;

        public StringClassCreator() { }

        public StringClassCreator(string templateName, string runTimeTableName, string baseParams)
        {
            this.templateName = templateName;
            this.runTimeTableName = runTimeTableName;
            this.baseParams = baseParams;
        }

        public void Init(string templateName, string runTimeTableName, string baseParams)
        {
            this.templateName = templateName;
            this.runTimeTableName = runTimeTableName;
            this.baseParams = baseParams;
        }


        //
        //{
        //double:avgBal1:not_null,
        //double:avgBal2:null,
        //date:startDate:not_null,
        //date:endDate:null
        //}


        public string BuildQMethod(List<string> drvdParams, List<string> qList)
        {
            string cntrlStructure = @"";

            for (int x = 0; x < drvdParams.Count; x++)
            {

                string expression = "", replace = "";

                List<string> paramList = ParamParser.GetParamList(drvdParams[x]);

                for (int y = 0; y < paramList.Count; y++)
                {
                    string paramName = ParamParser.GetParamName(paramList[y]);

                    if (String.IsNullOrEmpty(expression))
                    { 
                        
                        expression = String.Format("{0}{1}", paramName, GetAssignmentSnipnet(ParamParser.GetParamValue(paramList[y]))); 

                        if (paramName != "undefined") 
                            replace = string.Format(@".Replace(""@{0}"", {0})", paramName); 

                    } 
                    else
                    {

                        expression = String.Format("{0} && {1}{2}", expression, paramName, GetAssignmentSnipnet(ParamParser.GetParamValue(paramList[y]))); 

                        if(string.IsNullOrEmpty(replace) && paramName != "undefined") 
                        { 
                            replace = string.Format(@".Replace(""@{0}"", {0})", paramName); 
                        } 
                        else  
                            replace = string.Format(@"{0}.Replace(""@{1}"", {1})", replace, paramName); 

                    }
                     
                }//Ends the inner Loop


                if (String.IsNullOrEmpty(cntrlStructure))
                {
                    cntrlStructure = String.Format(@"if({0})
                    [[
                        q = @""{1}""{2};
                    ]]

                    ", expression, qList[x], replace);
                }
                else
                {
                    cntrlStructure = String.Format(@"{0}
                        else if({1})
                        [[
                             q = ""{2}"";
                        ]]
                        ", cntrlStructure, expression, qList[x]);
                }


            }//Ends the outer for loop


            return cntrlStructure;

        }

        //Method not in user for now
        public string BuildValAssignmentMethod(string baseParams)
        {
            string assignmentMthd = "";

            List<string> paramList = ParamParser.GetParamList(baseParams);

            string assignmnetStatement = "";
            string mthdSignature = "";

            for (int y = 0; y < paramList.Count; y++)
            {

                if (assignmnetStatement == "")
                {
                    mthdSignature = String.Format("{0} {1}", ParamParser.GetDataType(paramList[y]), ParamParser.GetParamName(paramList[y]));
                    assignmnetStatement = String.Format("this.{0} = {0};", ParamParser.GetParamName(paramList[y]));
                }
                else
                {
                    mthdSignature = String.Format("{2}, {0} {1}", ParamParser.GetDataType(paramList[y]), ParamParser.GetParamName(paramList[y]), mthdSignature);
                    assignmnetStatement = String.Format("{1} this.{0} = {0};", ParamParser.GetParamName(paramList[y]), assignmnetStatement);
                }
       
            }//Ends the inner Loop


       
            assignmentMthd = String.Format(@"

public void SetVals({0})
[[
    {1}
]]

", mthdSignature, assignmnetStatement);


            return assignmentMthd;

        }




        private string GetAssignmentSnipnet(string drvdParamValue)
        {
            return drvdParamValue == "not_null" ? " != null" : " == null";
        }



        public string GetProperty(string param)
        {
            string property = "";

            /*This place is commented for now*/

            //string paramType = ParamParser.GetDataType(param);
            //if(!paramType.Equals("string", StringComparison.OrdinalIgnoreCase))
            //    property = String.Format(@"public {0}? {1} [[ get; set; ]]", paramType, ParamParser.GetParamName(param));
            //else
            //    property = String.Format(@"public {0} {1} [[ get; set; ]]", paramType, ParamParser.GetParamName(param));

            property = String.Format(@"public string {0} [[ get; set; ]]",  ParamParser.GetParamName(param));

            return property;

        }//Ends GetProperty function






        public string GetClass(String baseParams, List<string> drvdParams, List<string> qList)
        {
            String str = "";


            string properties = "";

            List<string> paramList = ParamParser.GetParamList(this.baseParams);

            for (int x = 0; x < paramList.Count; x++)
            {
                properties += GetProperty(paramList[x]);
            }







            str = String.Format(@"namespace QryGn.Lib[[ using System; public class {0} [[ 

{1} 


public string GetQ()[[ string q = ""No Qry""; 
{2}
return q; ]] ]] ]]",
this.templateName, properties, BuildQMethod(drvdParams, qList)
);


            return str;
        }


    }



}
