﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryGn.Lib.BizObjs
{
    public class ParamParser
    {

        public static object[] ParseValues(string baseParams, string values)
        {

            List<string> paramList = ParamParser.GetParamList(baseParams);

            values = values.Replace("{", "").Replace("}", "");
            string[] values_list = values.Split(new string[] { "|^" }, StringSplitOptions.None);

            object[] obj_list = new object[values_list.Length];
            
            for(int x = 0; x < obj_list.Length; x++)
            {
                if (!String.IsNullOrEmpty(values_list[x]))
                    obj_list[x] = values_list[x];
                //obj_list[x] = ConvertToType(GetDataType(paramList[x]), values_list[x]);
            }//Ends the for loop

            return obj_list;
        }

        public static List<string> GetParamList(string param_s)
        {
            return param_s.Replace("{", "").Replace("}", "").Split(',').ToList<string>();
        }

        public static string GetDataType(string param)
        {
            //return Split(param)[0] == "date" ? "DateTime": Split(param)[0];
            return "string";
        }

        public static string GetParamName(string param)
        {
            return Split(param)[1];
        }

        public static string GetParamValue(string param)
        {
            return Split(param)[2];
        }


        private static string[] Split(string param)
        {
            return param.Split(':');
        }

        public static object ConvertToType(string typeName, string value)
        {
            object obj = null;

            if (typeName == "int")
                obj = TypeConverter.ToInteger(value);
            else if (typeName == "decimal" || typeName == "double")
                obj = TypeConverter.ToDecimal(value);
            else if (typeName == "Date" || typeName == "DateTime")
                obj = TypeConverter.ToDateTime(value);


            return obj;
        }


    }
}
