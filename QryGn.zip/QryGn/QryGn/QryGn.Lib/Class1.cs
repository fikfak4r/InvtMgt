﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QryGn.Lib
{
    using System;
    public class AverageBalance
    {

        public int? avgBal1 { get; set; }
        public int? avgBal2 { get; set; }
        public DateTime? startDate { get; set; }
        public DateTime? endDate { get; set; }


        public string GetQ()
        {
            string q = "Qry";
            if (avgBal1 != null && avgBal2 != null && startDate != null && endDate == null)
            {
                q = "Select * from AccountSummaryDemand avgBal2";
            }


            else if (avgBal1 != null && avgBal2 == null && startDate != null && endDate == null)
            {
                q = "Select * from AccountSummaryDemand";
            }

            return q;
        }
    }
}