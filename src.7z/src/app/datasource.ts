import { QueryBuilder, ColumnsModel } from '@syncfusion/ej2-querybuilder'
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Button } from '@syncfusion/ej2-buttons';
import { cssClass } from '@syncfusion/ej2-lists';
import { getComponent } from '@syncfusion/ej2-base';
import { CompSnippets } from './app1'
import { DataManager } from '@syncfusion/ej2-data';


let count:number = 0;


export let columnsModel: ColumnsModel[] = [
    {
        field: 'Retail', label: 'Retail', type: 'string', operators:[{key:'Equal',value:'equal'}],
        template: {
            create: () => {
                ++count
                return CompSnippets.Create(count);

            },
            write: (args: { elements: Element, values: string[] | string, operator: string }) => {

                CompSnippets.Write(args, 'Retail');

            }, destroy: (args: { elementId: string }) => {
                
            },
        }
    },
    {
        field: 'Transacting', label: 'Transacting', type: 'string',
        template: {
            create: () => {
                ++count
                return CompSnippets.Create(count);
            },
            write: (args: { elements: Element, values: string[] | string, operator: string }) => {

                CompSnippets.Write(args, 'Transacting');

            }, destroy: (args: { elementId: string }) => {
                
            },
        }
    },
    { field: 'TelecomCustomers', label: 'Telecom Customers', type: 'string' }
]



export let data: Array<any> = [
    { Category: 'Transacting', Template: 'Temp_USSDNonTransacting', fields: ['', ''] },
    { Category: 'Retail', Template: 'Temp_ActiveRetail', fields: ['', ''] },
    { Category: '', Template: '', fields: ['', ''] },
    { Category: '', Template: '', fields: ['', ''] },
    { Category: '', Template: '', fields: ['', ''] },
    { Category: '', Template: '', fields: ['', ''] },
    { Category: '', Template: '', fields: ['', ''] },
    { Category: '', Template: '', fields: ['', ''] }
]

let dmData: DataManager = new DataManager({ json: data })

export function DataMgr(): DataManager {
    return dmData
}