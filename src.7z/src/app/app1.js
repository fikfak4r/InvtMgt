define(["require", "exports", "@syncfusion/ej2-dropdowns", "@syncfusion/ej2-buttons", "./datasource", "@syncfusion/ej2-data"], function (require, exports, ej2_dropdowns_1, ej2_buttons_1, datasource_1, ej2_data_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var CompSnippets = (function () {
        function CompSnippets() {
        }
        CompSnippets.Create = function (index) {
            var elem = document.createElement('div');
            elem.setAttribute('class', 'param-area');
            elem.setAttribute('id', 'param-area_' + index);
            var inputElm = document.createElement('input');
            inputElm.setAttribute('id', 'input_' + index);
            elem.appendChild(inputElm);
            var btnElm = document.createElement('button');
            btnElm.setAttribute('id', 'btn_' + index);
            elem.appendChild(btnElm);
            return elem;
        };
        CompSnippets.Write = function (args, category) {
            var drpdwn = new ej2_dropdowns_1.DropDownList({
                fields: { text: 'Template', value: 'Template' },
                dataSource: datasource_1.DataMgr(),
                query: new ej2_data_1.Query().where('Category', 'equal', category)
            });
            drpdwn.appendTo($('#' + args.elements.id + " input")[0]);
            var btn = new ej2_buttons_1.Button({ content: 'Select', cssClass: 'e-success' });
            btn.appendTo($('#' + args.elements.id + " button")[0]);
            btn.element.onclick = function () {
                alert(btn.element.id);
            };
        };
        return CompSnippets;
    }());
    exports.CompSnippets = CompSnippets;
    var TemplateRef = (function () {
        function TemplateRef() {
        }
        Object.defineProperty(TemplateRef.prototype, "Button", {
            get: function () {
                return this._button;
            },
            set: function (button) {
                this._button = button;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TemplateRef.prototype, "Dialog", {
            get: function () {
                return this._dialog;
            },
            set: function (dialog) {
                this._dialog = dialog;
            },
            enumerable: true,
            configurable: true
        });
        return TemplateRef;
    }());
    exports.TemplateRef = TemplateRef;
});
