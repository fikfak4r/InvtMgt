import { ColumnsModel } from "@syncfusion/ej2-querybuilder";

export interface QryParam {
     Category:string
      Template: string
        fields?: ColumnsModel[] 
}

export class SmoothDataUtilities{

public static GetModelDailogId(index:number){
  return `dialog${index}`
}

}
