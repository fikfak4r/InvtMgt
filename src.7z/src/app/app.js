define(["require", "exports", "@syncfusion/ej2-base", "@syncfusion/ej2-layouts", "@syncfusion/ej2-buttons", "jquery", "./app1"], function (require, exports, ej2_base_1, ej2_layouts_1, ej2_buttons_1, $, app1_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    ej2_base_1.enableRipple(true);
    var grandSplitter = new ej2_layouts_1.Splitter({
        width: "1005px",
        height: "100%",
        paneSettings: [{ size: "855px" }, { size: '265px' }]
    });
    grandSplitter.appendTo("#grand-splitter");
    var count = 1;
    var btn1 = new ej2_buttons_1.Button({
        cssClass: "e-success"
    }, '#btn1');
    btn1.element.setAttribute('title', 'Get the query editor dialog');
    btn1.element.onclick = function () {
        ++count;
        $("#defaultDialog").after("<div id='dialog" + count + "'></div>");
        var dialog = app1_1.QryDialog.GetDialog("Dialog " + count);
        dialog.appendTo("#dialog" + count);
        app1_1.QryQueryBuilder.GetQueryBuilder().appendTo($(dialog.element).find('.e-dlg-content')[0]);
        dialog.element.onmousedown = function () {
            var zIndx = 100000 + ++count + 1;
            dialog.element.style.zIndex = zIndx.toString();
        };
    };
});
