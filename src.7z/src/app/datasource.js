define(["require", "exports", "./app1", "@syncfusion/ej2-data"], function (require, exports, app1_1, ej2_data_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var count = 0;
    exports.columnsModel = [
        {
            field: 'Retail', label: 'Retail', type: 'string', operators: [{ key: 'Equal', value: 'equal' }],
            template: {
                create: function () {
                    ++count;
                    return app1_1.CompSnippets.Create(count);
                },
                write: function (args) {
                    app1_1.CompSnippets.Write(args, 'Retail', count);
                }, destroy: function (args) {
                },
            }
        },
        {
            field: 'Transacting', label: 'Transacting', type: 'string',
            template: {
                create: function () {
                    ++count;
                    return app1_1.CompSnippets.Create(count);
                },
                write: function (args) {
                    app1_1.CompSnippets.Write(args, 'Transacting', count);
                }, destroy: function (args) {
                },
            }
        },
        { field: 'TelecomCustomers', label: 'Telecom Customers', type: 'string' }
    ];
    exports.data = [
        { Category: 'Transacting', Template: 'Temp_USSDNonTransacting', fields: [] },
        { Category: 'Retail', Template: 'Temp_ActiveRetail', fields: [
                {
                    field: 'CUST_ID', label: 'CUST_ID', type: 'string', operators: [{ key: 'Equal', value: 'equal' }]
                },
                {
                    field: 'ARC', label: 'ARC', type: 'string'
                }
            ] },
        { Category: '', Template: '' },
        { Category: '', Template: '' },
        { Category: '', Template: '' },
        { Category: '', Template: '' },
        { Category: '', Template: '' },
        { Category: '', Template: '' }
    ];
    var dmData = new ej2_data_1.DataManager({ json: exports.data });
    function DataMgr() {
        return dmData;
    }
    exports.DataMgr = DataMgr;
});
