define(["require", "exports", "@syncfusion/ej2-data"], function (require, exports, ej2_data_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    let count = 0;
    function GetColumsModel(qryBldrObj) {
        return [
            {
                field: 'Root', label: 'Root', type: 'string', operators: [{ key: 'Equal', value: 'equal' }],
            },
            {
                field: 'Retail', label: 'Retail', type: 'string', operators: [{ key: 'Equal', value: 'equal' }],
            },
            {
                field: 'Transacting', label: 'Transacting', type: 'string',
            },
            { field: 'TelecomCustomers', label: 'Telecom Customers', type: 'string' }
        ];
    }
    exports.GetColumsModel = GetColumsModel;
    exports.data = [
        { Category: 'Root', Template: 'CustomerDetails', fields: [
                {
                    field: 'CUST_ID', label: 'CUST_ID', type: 'string', operators: [{ key: 'Equal', value: 'equal' }]
                },
                {
                    field: 'HAS_VLD_MOBLNUM_FLG', label: 'HAS_VLD_MOBLNUM_FLG', type: 'boolean'
                },
                {
                    field: 'USSD_IND', label: 'USSD_IND', type: 'boolean'
                }
            ] },
        { Category: 'Transacting', Template: 'Temp_USSDNonTransacting', fields: [] },
        { Category: 'Retail', Template: 'Temp_ActiveRetail', fields: [
                {
                    field: 'CUST_ID', label: 'CUST_ID', type: 'string', operators: [{ key: 'Equal', value: 'equal' }]
                },
                {
                    field: 'ARC', label: 'ARC', type: 'string'
                }
            ] },
        { Category: '', Template: '' },
        { Category: '', Template: '' },
        { Category: '', Template: '' },
        { Category: '', Template: '' },
        { Category: '', Template: '' },
        { Category: '', Template: '' }
    ];
    let dmData = new ej2_data_1.DataManager({ json: exports.data });
    function DataMgr() {
        return dmData;
    }
    exports.DataMgr = DataMgr;
});
