import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Button } from '@syncfusion/ej2-buttons';
import {columnsModel,data,DataMgr} from './datasource'
import { Query } from '@syncfusion/ej2-data';
import { Dialog } from '@syncfusion/ej2-popups';

export class CompSnippets{
    
    constructor(){}

public static Create(index: number){

    var elem = document.createElement('div')
    elem.setAttribute('class', 'param-area')
    elem.setAttribute('id', 'param-area_' + index)

    var inputElm = document.createElement('input')
    inputElm.setAttribute('id', 'input_' + index)
    elem.appendChild(inputElm);

    var btnElm = document.createElement('button')
    btnElm.setAttribute('id', 'btn_' + index)

    elem.appendChild(btnElm)

    return elem
}

public static Write(args:{elements:Element, values:string[]|string, operator:string}, category:string){

    let drpdwn:DropDownList = new DropDownList({
        fields:{text:'Template',value:'Template'},
        dataSource:DataMgr(),
        query:new Query().where('Category', 'equal', category)
    })
    
   drpdwn.appendTo($('#' + args.elements.id + " input")[0]);


   let btn:Button = new Button({content:'Select', cssClass:'e-success'})
  

   btn.appendTo($('#' + args.elements.id + " button")[0]);
   
   btn.element.onclick = () => {
    alert(btn.element.id)
}

}


}


export class TemplateRef {
    private _button:Button;
    private _dialog:Dialog;

    public set Button(button: Button){
        this._button = button;
    }

    public get Button(){
        return this._button;
    }

    public set Dialog(dialog: Dialog){
        this._dialog = dialog;
    }

    public get Dialog(){
        return this._dialog;
    }



}