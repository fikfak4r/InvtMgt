import { getComponent, enableRipple } from '@syncfusion/ej2-base';
import { Dialog } from "@syncfusion/ej2-popups"
enableRipple(true);
import { Splitter } from "@syncfusion/ej2-layouts"
import { Button } from '@syncfusion/ej2-buttons'
import * as $ from 'jquery'
import { QryQueryBuilder, QryModelDef, QryDialog } from './app1'
import { SmoothDataUtilities } from './app2'
import { QueryBuilder } from '@syncfusion/ej2-querybuilder';
import { GetColumsModel } from './datasource';




let grandSplitter: Splitter = new Splitter({
    width: "1005px",
    height: "100%",
    paneSettings: [{ size: "855px" }, { size: '265px' }]
})
grandSplitter.appendTo("#grand-splitter");


// let splitter1:Splitter = new Splitter({
//     width:"100%",
//     height:"250px"
// })

// splitter1.appendTo("#splitter1")


let count: number = 1
let zIndexCount:number = 1000
let btn1: Button = new Button({
    cssClass: "e-success"
}, '#btn1');
let myQryBuilders:Array<QueryBuilder> = new Array<QueryBuilder>()
let qryModelDefRef:Array<QryModelDef> = new Array<QryModelDef>()

btn1.element.setAttribute('title', 'Get the query editor dialog')

btn1.element.onclick = (): void => {
    ++count;

    $("#defaultDialog").after("<div id='dialog" + count + "'></div>")

    
    let dialog: Dialog = QryDialog.GetDialog(`Dialog ${count}`)
    dialog.close = () =>{
        qryModelDefRef.find((x) => { return x.id == dialog.element.id}).State = false;
    }
    dialog.appendTo("#" + SmoothDataUtilities.GetModelDailogId(count));
    
    var qryModelDef = new QryModelDef()
    qryModelDef.State = true;
    qryModelDef.id = dialog.element.id

    var qrbldr = QryQueryBuilder.GetQueryBuilder()
    qryModelDef.qryBldr = qrbldr
    
    qrbldr.appendTo($(dialog.element).find('.e-dlg-content')[0]);

    QryQueryBuilder.SetTemplate(qrbldr, qryModelDef)

    qryModelDefRef.push(qryModelDef);

    

    dialog.element.onmousedown = () => {

        let zIndx = 100000 + ++zIndexCount + 1
        dialog.element.style.zIndex = zIndx.toString()

    }


 
let btn2: Button = new Button({
    cssClass: "e-success"
}, '#btn2');

btn2.element.setAttribute('title', 'Get query')
btn2.element.style.display = 'block'


btn2.element.onclick = () =>{



    qryModelDefRef
    .filter((obj:QryModelDef, index, list:Array<QryModelDef>) =>{return obj.State == true})
    .forEach((obj:QryModelDef, index, list:Array<QryModelDef>) =>{
        alert(JSON.stringify(obj.qryBldr.getValidRules(obj.qryBldr.rule)))
        alert(JSON.stringify(obj.paramQryBldr.getValidRules(obj.paramQryBldr.rule)))
        //obj.qryBldr.destroy();
        //alert('State: ' + obj.State + '  ' + index + '  ' + list.length + '   ID:' + obj.id)
 
    })


}


}



