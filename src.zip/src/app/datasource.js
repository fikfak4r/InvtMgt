define(["require", "exports", "./app1"], function (require, exports, app1_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.columnsModel = [
        { field: 'Retail', label: 'Retail', type: 'string',
            template: {
                create: () => {
                    return app1_1.CompSnippets.Create();
                },
                write: (args) => {
                    app1_1.CompSnippets.Write(args);
                }, destroy: (args) => {
                    alert('To be destroyed');
                },
            }
        },
        { field: 'Transacting', label: 'Transacting', type: 'string' },
        { field: 'TelecomCustomers', label: 'Telecom Customers', type: 'string' }
    ];
    exports.data = [
        { Category: '', Template: '', fields: ['', ''] },
        { Category: '', Template: '', fields: ['', ''] },
        { Category: '', Template: '', fields: ['', ''] },
        { Category: '', Template: '', fields: ['', ''] },
        { Category: '', Template: '', fields: ['', ''] },
        { Category: '', Template: '', fields: ['', ''] },
        { Category: '', Template: '', fields: ['', ''] },
        { Category: '', Template: '', fields: ['', ''] }
    ];
});
