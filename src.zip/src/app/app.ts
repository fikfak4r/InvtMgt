import { Dialog } from "@syncfusion/ej2-popups"
import { enableRipple } from '@syncfusion/ej2-base';
enableRipple(true);
import { Splitter } from "@syncfusion/ej2-layouts"
import { Button } from '@syncfusion/ej2-buttons'
import * as $ from 'jquery'
import { QryQueryBuilder, QryDialog } from './app1'
import { columnsModel } from './datasource'



let grandSplitter: Splitter = new Splitter({
    width: "1005px",
    height: "100%",
    paneSettings: [{ size: "855px" }, { size: '265px' }]
})
grandSplitter.appendTo("#grand-splitter");


// let splitter1:Splitter = new Splitter({
//     width:"100%",
//     height:"250px"
// })

// splitter1.appendTo("#splitter1")


let count: number = 1
let btn1: Button = new Button({
    cssClass: "e-success"
}, '#btn1');

btn1.element.setAttribute('title', 'Get the query editor dialog')

btn1.element.onclick = (): void => {
    ++count;

    $("#defaultDialog").after("<div id='dialog" + count + "'></div>")

    let dialog: Dialog = QryDialog.GetDialog(`Dialog ${count}`)
    dialog.appendTo("#dialog" + count);

    QryQueryBuilder.GetQueryBuilder().appendTo($(dialog.element).find('.e-dlg-content')[0]);

    dialog.element.onmousedown = () => {

        let zIndx = 100000 + ++count + 1
        dialog.element.style.zIndex = zIndx.toString()

    }




}



