import { QueryBuilder, ColumnsModel } from '@syncfusion/ej2-querybuilder'
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Button } from '@syncfusion/ej2-buttons';
import { cssClass } from '@syncfusion/ej2-lists';
import { getComponent } from '@syncfusion/ej2-base'; 
import { CompSnippets } from './app1'
import { DataManager } from '@syncfusion/ej2-data';
import {QryParam} from './app2'

let count:number = 0;

// let qryBldrObj:QueryBuilder;

// export let columnsModel: ColumnsModel[] = [
//     {
//         field: 'Root', label: 'Root', type: 'string', operators:[{key:'Equal',value:'equal'}],
//         template: {
//             create: () => {
//                 ++count
//                 return CompSnippets.Create(count);

//             },
//             write: (args: { elements: Element, values: string[] | string, operator: string }) => {

//                 CompSnippets.Write(args, 'Root', count, qryBldrObj);

//             }, 
//             destroy: (args: { elementId: string }) => {
                
//             },
//         }
//     },
//     {
//         field: 'Retail', label: 'Retail', type: 'string', operators:[{key:'Equal',value:'equal'}],
//         template: {
//             create: () => {
//                 ++count
//                 return CompSnippets.Create(count);

//             },
//             write: (args: { elements: Element, values: string[] | string, operator: string }) => {

//                 CompSnippets.Write(args, 'Retail', count, qryBldrObj);

//             }, destroy: (args: { elementId: string }) => {
                
//             },
//         }
//     },
//     {
//         field: 'Transacting', label: 'Transacting', type: 'string',
//         template: {
//             create: () => {
//                 ++count
//                 return CompSnippets.Create(count);
//             },
//             write: (args: { elements: Element, values: string[] | string, operator: string }) => {

//                 CompSnippets.Write(args, 'Transacting', count, qryBldrObj);

//             }, destroy: (args: { elementId: string }) => {
                
//             },
//         }
//     },
//     { field: 'TelecomCustomers', label: 'Telecom Customers', type: 'string' }
// ]


// export function GetColumsModel(qryBldrObj:QueryBuilder){
    
//     return [
//         {
//             field: 'Root', label: 'Root', type: 'string', operators:[{key:'Equal',value:'equal'}],
//             template: {
//                 create: () => {
//                     ++count
//                     return CompSnippets.Create(count);
    
//                 },
//                 write: (args: { elements: Element, values: string[] | string, operator: string }) => {
    
//                     CompSnippets.Write(args, 'Root', count, qryBldrObj);
    
//                 }, 
//                 destroy: (args: { elementId: string }) => {
//                     CompSnippets.Destroy(args)
//                 },
//             }
//         },
//         {
//             field: 'Retail', label: 'Retail', type: 'string', operators:[{key:'Equal',value:'equal'}],
//             template: {
//                 create: () => {
//                     ++count
//                     return CompSnippets.Create(count);
    
//                 },
//                 write: (args: { elements: Element, values: string[] | string, operator: string }) => {
    
//                     CompSnippets.Write(args, 'Retail', count, qryBldrObj);
    
//                 }, destroy: (args: { elementId: string }) => {
//                     CompSnippets.Destroy(args)
//                 },
//             }
//         },
//         {
//             field: 'Transacting', label: 'Transacting', type: 'string',
//             template: {
//                 create: () => {
//                     ++count
//                     return CompSnippets.Create(count);
//                 },
//                 write: (args: { elements: Element, values: string[] | string, operator: string }) => {
    
//                     CompSnippets.Write(args, 'Transacting', count, qryBldrObj);
    
//                 }, destroy: (args: { elementId: string }) => {
//                     CompSnippets.Destroy(args)
//                 },
//             }
//         },
//         { field: 'TelecomCustomers', label: 'Telecom Customers', type: 'string' }
//     ]
//     ;
// }

// export let data: Array<QryParam> = [
//     { Category: 'Root', Template: 'CustomerDetails', fields: [
//         {
//             field: 'CUST_ID', label: 'CUST_ID', type: 'string', operators:[{key:'Equal',value:'equal'}]
//         },
//         {
//             field: 'HAS_VLD_MOBLNUM_FLG', label: 'HAS_VLD_MOBLNUM_FLG', type: 'boolean'
//         },
//         {
//             field: 'USSD_IND', label: 'USSD_IND', type: 'boolean'
//         }
//     ] },
//     { Category: 'Transacting', Template: 'Temp_USSDNonTransacting', fields: [] },
//     { Category: 'Retail', Template: 'Temp_ActiveRetail', fields: [
//         {
//             field: 'CUST_ID', label: 'CUST_ID', type: 'string', operators:[{key:'Equal',value:'equal'}]
//         },
//         {
//             field: 'ARC', label: 'ARC', type: 'string'
//         }
//     ] },
//     { Category: '', Template: ''},
//     { Category: '', Template: ''},
//     { Category: '', Template: '' },
//     { Category: '', Template: '' },
//     { Category: '', Template: '' },
//     { Category: '', Template: '' }
// ]



export function GetColumsModel(qryBldrObj:QueryBuilder){
    
    return [
        {
            field: 'Root', label: 'Root', type: 'string', operators:[{key:'Equal',value:'equal'}],
        },
        {
            field: 'Retail', label: 'Retail', type: 'string', operators:[{key:'Equal',value:'equal'}],
        },
        {
            field: 'Transacting', label: 'Transacting', type: 'string',
        },
        { field: 'TelecomCustomers', label: 'Telecom Customers', type: 'string' }
    ]
    ;
}

export let data: Array<QryParam> = [
    { Category: 'Root', Template: 'CustomerDetails', fields: [
        {
            field: 'CUST_ID', label: 'CUST_ID', type: 'string', operators:[{key:'Equal',value:'equal'}]
        },
        {
            field: 'HAS_VLD_MOBLNUM_FLG', label: 'HAS_VLD_MOBLNUM_FLG', type: 'boolean'
        },
        {
            field: 'USSD_IND', label: 'USSD_IND', type: 'boolean'
        }
    ] },
    { Category: 'Transacting', Template: 'Temp_USSDNonTransacting', fields: [] },
    { Category: 'Retail', Template: 'Temp_ActiveRetail', fields: [
        {
            field: 'CUST_ID', label: 'CUST_ID', type: 'string', operators:[{key:'Equal',value:'equal'}]
        },
        {
            field: 'ARC', label: 'ARC', type: 'string'
        }
    ] },
    { Category: '', Template: ''},
    { Category: '', Template: ''},
    { Category: '', Template: '' },
    { Category: '', Template: '' },
    { Category: '', Template: '' },
    { Category: '', Template: '' }
]



let dmData: DataManager = new DataManager({ json: data })

export function DataMgr(): DataManager {
    return dmData
}