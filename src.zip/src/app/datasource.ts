import {QueryBuilder, ColumnsModel} from '@syncfusion/ej2-querybuilder'
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Button } from '@syncfusion/ej2-buttons';
import { cssClass } from '@syncfusion/ej2-lists';
import { getComponent } from '@syncfusion/ej2-base';
import { CompSnippets } from './app1'
export let columnsModel:ColumnsModel[] = [
    {field:'Retail',label:'Retail', type:'string',
template:{
    create:()=>{

        return CompSnippets.Create();
    },
    write:(args:{elements:Element, values:string[]|string, operator:string}) => {
     
        CompSnippets.Write(args);
        
    }, destroy: (args: { elementId: string }) => {
        alert('To be destroyed')
        //(getComponent(document.getElementById(args.elementId), 'checkbox') as CheckBox).destroy();
    },
}
},
    {field:'Transacting', label:'Transacting', type:'string'},
    {field:'TelecomCustomers', label:'Telecom Customers', type:'string'}
]



export let data:Array<any> =[
    {Category:'', Template:'', fields:['','']},
    {Category:'', Template:'', fields:['','']},
    {Category:'', Template:'', fields:['','']},
    {Category:'', Template:'', fields:['','']},
    {Category:'', Template:'', fields:['','']},
    {Category:'', Template:'', fields:['','']},
    {Category:'', Template:'', fields:['','']},
    {Category:'', Template:'', fields:['','']}
]