define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class SmoothDataUtilities {
        static GetModelDailogId(index) {
            return `dialog${index}`;
        }
    }
    exports.SmoothDataUtilities = SmoothDataUtilities;
});
