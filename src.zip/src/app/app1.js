define(["require", "exports", "@syncfusion/ej2-dropdowns", "@syncfusion/ej2-buttons", "./datasource", "@syncfusion/ej2-data", "@syncfusion/ej2-popups", "@syncfusion/ej2-querybuilder", "@syncfusion/ej2-base"], function (require, exports, ej2_dropdowns_1, ej2_buttons_1, datasource_1, ej2_data_1, ej2_popups_1, ej2_querybuilder_1, ej2_base_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    let count = 5;
    let count_1 = 0;
    let dataManager;
    class CompSnippets {
        constructor() {
            dataManager = datasource_1.DataMgr();
        }
        static Create(index) {
            var inputElm = document.createElement('input');
            inputElm.setAttribute('type', 'text');
            return inputElm;
        }
        static Write(args, category, index, qryBldrObj, qryModelDefRef) {
            var btnElm = document.createElement('button');
            btnElm.setAttribute('id', 'btn_' + index);
            $('#' + args.elements.id).after(btnElm);
            let drpdwn = new ej2_dropdowns_1.DropDownList({
                fields: { text: 'Template', value: 'Template' },
                dataSource: datasource_1.DataMgr(),
                query: new ej2_data_1.Query().where('Category', 'equal', category),
                change: (e) => {
                    qryBldrObj.notifyChange(e.itemData.value, e.element);
                }
            });
            drpdwn.appendTo('#' + args.elements.id);
            let btn = new ej2_buttons_1.Button({ content: 'Select', cssClass: 'e-success' });
            btn.appendTo($('#' + 'btn_' + index)[0]);
            btn.element.onclick = () => {
                var dialog = undefined;
                if ($('#' + btn.element.id.replace('btn_', 'pramDialog')).length)
                    dialog = ej2_base_1.getComponent($('#' + btn.element.id.replace('btn_', 'pramDialog'))[0], 'dialog');
                if (!$('#' + btn.element.id.replace('btn_', 'pramDialog')).length && dialog == undefined) {
                    let ddlst = ej2_base_1.getComponent($('#' + btn.element.id).parent('div').find('input')[0], 'dropdownlist');
                    if (ddlst.value) {
                        CompSnippets.CreateParamQueryBuilder(index, category, ddlst, qryModelDefRef);
                    }
                }
                else {
                    ej2_base_1.getComponent($('#' + btn.element.id.replace('btn_', 'pramDialog'))[0], 'dialog').show();
                }
            };
        }
        static CreateParamQueryBuilder(index, category, ddlst, qryModelDefRef) {
            $("#defaultDialog").after("<div id='pramDialog" + index + "'></div>");
            let dialog = QryDialog.GetParamSettingsDialog(index, 'Dialog');
            dialog.appendTo("#pramDialog" + index);
            let predicate = new ej2_data_1.Predicate('Category', 'equal', category);
            predicate = predicate.and('Template', 'equal', ddlst.value.toString());
            let objs = datasource_1.DataMgr().executeLocal(new ej2_data_1.Query().where(predicate));
            if (objs) {
                var qb = QryQueryBuilder.GetParamSettingsQueryBuilder(objs[0].fields);
                qb.appendTo($(dialog.element).find('.e-dlg-content')[0]);
                qryModelDefRef.paramQryBldr = qb;
            }
        }
        static Destroy(args) {
            let dropdown = ej2_base_1.getComponent($('#' + args.elementId)[0], 'dropdownlist');
            if (dropdown) {
                dropdown.destroy();
            }
            var btn = $('#' + args.elementId).parent('div').children('button');
            if (btn.length) {
                btn.hide();
            }
        }
    }
    exports.CompSnippets = CompSnippets;
    class QryModelDef {
    }
    exports.QryModelDef = QryModelDef;
    class QryDialog {
        constructor() { }
        static GetDialog(title) {
            let dialog = new ej2_popups_1.Dialog({
                header: title,
                width: "750px",
                overlayClick: () => { alert("So clicked"); },
                allowDragging: true,
                showCloseIcon: true,
                isModal: false,
                target: document.getElementById("container"),
                position: { X: 'left', Y: 'top' },
            });
            return dialog;
        }
        static GetParamSettingsDialog(index, title) {
            let dialog = new ej2_popups_1.Dialog({
                header: title,
                width: "750px",
                overlayClick: () => { alert("So clicked"); },
                allowDragging: true,
                showCloseIcon: true,
                isModal: false,
                target: document.getElementById("container"),
                position: { X: 'left', Y: 'top' },
                close: () => {
                }
            });
            return dialog;
        }
        static RaiseFocus() {
        }
    }
    exports.QryDialog = QryDialog;
    class QryQueryBuilder {
        constructor() {
        }
        static GetQueryBuilder() {
            var qryBldr = new ej2_querybuilder_1.QueryBuilder({
                width: '100%',
            });
            qryBldr.columns = datasource_1.GetColumsModel(qryBldr);
            return qryBldr;
        }
        static SetTemplate(qryBldrObj, qryModelDefRef) {
            qryBldrObj.columns.forEach((colModel, index, colsModel) => {
                colModel.template = {
                    create: () => {
                        ++count_1;
                        return CompSnippets.Create(count_1);
                    },
                    write: (args) => {
                        CompSnippets.Write(args, colModel.field, count_1, qryBldrObj, qryModelDefRef);
                    },
                    destroy: (args) => {
                        CompSnippets.Destroy(args);
                    },
                };
            });
        }
        static GetParamSettingsQueryBuilder(columnsMdl) {
            let columnData = [
                { field: 'EmployeeID', label: 'EmployeeID', type: 'number' },
                { field: 'FirstName', label: 'FirstName', type: 'string' },
                { field: 'TitleOfCourtesy', label: 'Title Of Courtesy', type: 'boolean', values: ['Mr.', 'Mrs.'] },
                { field: 'Title', label: 'Title', type: 'string' },
                { field: 'HireDate', label: 'HireDate', type: 'date', format: 'dd/MM/yyyy' },
                { field: 'Country', label: 'Country', type: 'string' },
                { field: 'City', label: 'City', type: 'string' }
            ];
            return new ej2_querybuilder_1.QueryBuilder({
                width: '100%',
                columns: columnsMdl,
            });
        }
    }
    exports.QryQueryBuilder = QryQueryBuilder;
});
