define(["require", "exports", "@syncfusion/ej2-dropdowns", "@syncfusion/ej2-buttons"], function (require, exports, ej2_dropdowns_1, ej2_buttons_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class CompSnippets {
        constructor() { }
        static Create() {
            var elem = document.createElement('p');
            elem.setAttribute('class', 'param-area');
            elem.setAttribute('id', 'param-area');
            elem.appendChild(document.createElement('input'));
            elem.appendChild(document.createElement('button'));
            return elem;
        }
        static Write(args) {
            let drpdwn = new ej2_dropdowns_1.DropDownList({
                fields: { text: 'txt', value: 'val' },
                dataSource: [{ txt: 'Fik 1', val: 'Fik 2' }]
            });
            drpdwn.appendTo($('#' + args.elements.id + " input")[0]);
            let btn = new ej2_buttons_1.Button({ content: 'Select', cssClass: 'e-success' });
        }
    }
    exports.CompSnippets = CompSnippets;
});
