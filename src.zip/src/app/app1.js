define(["require", "exports", "@syncfusion/ej2-dropdowns", "@syncfusion/ej2-buttons", "./datasource", "@syncfusion/ej2-data", "@syncfusion/ej2-popups", "@syncfusion/ej2-querybuilder", "@syncfusion/ej2-base"], function (require, exports, ej2_dropdowns_1, ej2_buttons_1, datasource_1, ej2_data_1, ej2_popups_1, ej2_querybuilder_1, ej2_base_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var count = 5;
    var dataManager;
    var CompSnippets = (function () {
        function CompSnippets() {
            dataManager = datasource_1.DataMgr();
        }
        CompSnippets.Create = function (index) {
            var elem = document.createElement('div');
            elem.setAttribute('class', 'param-area');
            elem.setAttribute('id', 'param-area_' + index);
            var inputElm = document.createElement('input');
            inputElm.setAttribute('id', 'input_' + index);
            elem.appendChild(inputElm);
            var btnElm = document.createElement('button');
            btnElm.setAttribute('id', 'btn_' + index);
            elem.appendChild(btnElm);
            return elem;
        };
        CompSnippets.Write = function (args, category, index) {
            var drpdwn = new ej2_dropdowns_1.DropDownList({
                fields: { text: 'Template', value: 'Template' },
                dataSource: datasource_1.DataMgr(),
                query: new ej2_data_1.Query().where('Category', 'equal', category)
            });
            drpdwn.appendTo($('#' + args.elements.id + " input")[0]);
            var btn = new ej2_buttons_1.Button({ content: 'Select', cssClass: 'e-success' });
            btn.appendTo($('#' + 'btn_' + index)[0]);
            btn.element.onclick = function () {
                var dialog = undefined;
                try {
                    dialog = ej2_base_1.getComponent($('#' + btn.element.id.replace('btn_', 'pramDialog'))[0], 'dialog');
                }
                catch (error) {
                    dialog = undefined;
                }
                $('#' + btn.element.id.replace('btn_', 'pramDialog'))[0];
                if (!$('#' + btn.element.id.replace('btn_', 'pramDialog')).length && dialog == undefined) {
                    $("#defaultDialog").after("<div id='pramDialog" + index + "'></div>");
                    var dialog_1 = QryDialog.GetParamSettingsDialog(index, 'Dialog');
                    dialog_1.appendTo("#pramDialog" + index);
                    var objs = datasource_1.DataMgr().executeLocal(new ej2_data_1.Query().where('Category', 'equal', category));
                    QryQueryBuilder.GetParamSettingsQueryBuilder(objs[0].fields).appendTo($(dialog_1.element).find('.e-dlg-content')[0]);
                }
                else {
                    ej2_base_1.getComponent($('#' + btn.element.id.replace('btn_', 'pramDialog'))[0], 'dialog').show();
                }
            };
        };
        return CompSnippets;
    }());
    exports.CompSnippets = CompSnippets;
    var QryDialog = (function () {
        function QryDialog() {
        }
        QryDialog.GetDialog = function (title) {
            var dialog = new ej2_popups_1.Dialog({
                header: title,
                width: "750px",
                overlayClick: function () { alert("So clicked"); },
                allowDragging: true,
                showCloseIcon: true,
                isModal: false,
                target: document.getElementById("container"),
                position: { X: 'left', Y: 'top' },
            });
            return dialog;
        };
        QryDialog.GetParamSettingsDialog = function (index, title) {
            var dialog = new ej2_popups_1.Dialog({
                header: title,
                width: "750px",
                overlayClick: function () { alert("So clicked"); },
                allowDragging: true,
                showCloseIcon: true,
                isModal: false,
                target: document.getElementById("container"),
                position: { X: 'left', Y: 'top' },
                close: function () {
                }
            });
            return dialog;
        };
        QryDialog.RaiseFocus = function () {
        };
        return QryDialog;
    }());
    exports.QryDialog = QryDialog;
    var QryQueryBuilder = (function () {
        function QryQueryBuilder() {
        }
        QryQueryBuilder.GetQueryBuilder = function () {
            var columnData = [
                { field: 'EmployeeID', label: 'EmployeeID', type: 'number' },
                { field: 'FirstName', label: 'FirstName', type: 'string' },
                { field: 'TitleOfCourtesy', label: 'Title Of Courtesy', type: 'boolean', values: ['Mr.', 'Mrs.'] },
                { field: 'Title', label: 'Title', type: 'string' },
                { field: 'HireDate', label: 'HireDate', type: 'date', format: 'dd/MM/yyyy' },
                { field: 'Country', label: 'Country', type: 'string' },
                { field: 'City', label: 'City', type: 'string' }
            ];
            return new ej2_querybuilder_1.QueryBuilder({
                width: '100%',
                columns: datasource_1.columnsModel,
            });
        };
        QryQueryBuilder.GetParamSettingsQueryBuilder = function (columnsMdl) {
            var columnData = [
                { field: 'EmployeeID', label: 'EmployeeID', type: 'number' },
                { field: 'FirstName', label: 'FirstName', type: 'string' },
                { field: 'TitleOfCourtesy', label: 'Title Of Courtesy', type: 'boolean', values: ['Mr.', 'Mrs.'] },
                { field: 'Title', label: 'Title', type: 'string' },
                { field: 'HireDate', label: 'HireDate', type: 'date', format: 'dd/MM/yyyy' },
                { field: 'Country', label: 'Country', type: 'string' },
                { field: 'City', label: 'City', type: 'string' }
            ];
            return new ej2_querybuilder_1.QueryBuilder({
                width: '100%',
                columns: columnsMdl,
            });
        };
        return QryQueryBuilder;
    }());
    exports.QryQueryBuilder = QryQueryBuilder;
});
