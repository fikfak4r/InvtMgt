import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Button } from '@syncfusion/ej2-buttons';

export class CompSnippets{
    
    constructor(){}

public static Create(){

    var elem = document.createElement('p')
    elem.setAttribute('class', 'param-area')
    elem.setAttribute('id', 'param-area')

    elem.appendChild(document.createElement('input'))
    elem.appendChild(document.createElement('button'))

   

    return elem
}

public static Write(args:{elements:Element, values:string[]|string, operator:string}){

    let drpdwn:DropDownList = new DropDownList({
        fields:{text:'txt',value:'val'},
        dataSource:[{txt:'Fik 1',val:'Fik 2'}]
    })
    
   drpdwn.appendTo($('#' + args.elements.id + " input")[0]);
   //drpdwn.appendTo("#" + args.elements[0].id);

   let btn:Button = new Button({content:'Select', cssClass:'e-success'})
   //btn.appendTo($('#' + args.elements.id + " button")[0]);
   //btn.appendTo('#' + args.elements[1].id);
//    btn.element.onclick = () => {
//         alert(btn.element.id)
//    }

}


}