import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Button } from '@syncfusion/ej2-buttons';
import { columnsModel, data, DataMgr } from './datasource'
import { Query, DataManager } from '@syncfusion/ej2-data';
import { Dialog } from '@syncfusion/ej2-popups';
import { QryParam } from './app2';
import { QueryBuilder, ColumnsModel } from '@syncfusion/ej2-querybuilder'
import { getComponent, Component } from '@syncfusion/ej2-base';

let count: number = 5;
let dataManager: DataManager;

export class CompSnippets {

    constructor() {
        dataManager = DataMgr();
    }

    public static Create(index: number) {

        var elem = document.createElement('div')
        elem.setAttribute('class', 'param-area')
        elem.setAttribute('id', 'param-area_' + index)

        var inputElm = document.createElement('input')
        inputElm.setAttribute('id', 'input_' + index)
        elem.appendChild(inputElm);

        var btnElm = document.createElement('button')
        btnElm.setAttribute('id', 'btn_' + index)

        elem.appendChild(btnElm)

        return elem
    }

    public static Write(args: { elements: Element, values: string[] | string, operator: string }, category: string, index: number) {

        let drpdwn: DropDownList = new DropDownList({
            fields: { text: 'Template', value: 'Template' },
            dataSource: DataMgr(),
            query: new Query().where('Category', 'equal', category)
        })

        drpdwn.appendTo($('#' + args.elements.id + " input")[0]);


        let btn: Button = new Button({ content: 'Select', cssClass: 'e-success' })


        btn.appendTo($('#' + 'btn_' + index)[0]);

        btn.element.onclick = () => {

            //++count;
        
            var dialog = undefined;
             try {
                dialog = (getComponent($('#'+btn.element.id.replace('btn_','pramDialog'))[0], 'dialog') as Dialog)
            } catch (error) {
                dialog = undefined;
            } 

     
            
            $('#'+btn.element.id.replace('btn_','pramDialog'))[0]
            if (!$('#'+btn.element.id.replace('btn_','pramDialog')).length && dialog == undefined) {
                
                $("#defaultDialog").after("<div id='pramDialog" + index + "'></div>")

                let dialog: Dialog = QryDialog.GetParamSettingsDialog(index, 'Dialog')
                dialog.appendTo("#pramDialog" + index);
                let objs: Array<QryParam> = <Array<QryParam>>DataMgr().executeLocal(new Query().where('Category', 'equal', category))

                QryQueryBuilder.GetParamSettingsQueryBuilder(objs[0].fields).appendTo($(dialog.element).find('.e-dlg-content')[0]);

            } else {
                
                (getComponent($('#'+btn.element.id.replace('btn_','pramDialog'))[0], 'dialog') as Dialog).show();
            }
        }

    }


}



export class QryDialog {

    constructor() { }

    public static GetDialog(title: string): Dialog {

        let dialog: Dialog = new Dialog({
            header: title,
            width: "750px",
            overlayClick: () => { alert("So clicked") },
            allowDragging: true,
            showCloseIcon: true,
            isModal: false,
            target: document.getElementById("container"),
            position: { X: 'left', Y: 'top' },
            //visible:false,

        })

        return dialog;
    }

    public static GetParamSettingsDialog(index:number, title: string): Dialog {

        let dialog: Dialog = new Dialog({
            header: title,
            width: "750px",
            overlayClick: () => { alert("So clicked") },
            allowDragging: true,
            showCloseIcon: true,
            isModal: false,
            target: document.getElementById("container"),
            position: { X: 'left', Y: 'top' },
            close:() => {
                //document.getElementById('dialog' + index).style.display = 'block';
            }
            
            
            //visible:false,

        })

        return dialog;
    }


    public static RaiseFocus() {

    }

}




export class QryQueryBuilder {
    constructor() {

    }

    public static GetQueryBuilder(): QueryBuilder {


        let columnData: ColumnsModel[] = [
            { field: 'EmployeeID', label: 'EmployeeID', type: 'number' },
            { field: 'FirstName', label: 'FirstName', type: 'string' },
            { field: 'TitleOfCourtesy', label: 'Title Of Courtesy', type: 'boolean', values: ['Mr.', 'Mrs.'] },
            { field: 'Title', label: 'Title', type: 'string' },
            { field: 'HireDate', label: 'HireDate', type: 'date', format: 'dd/MM/yyyy' },
            { field: 'Country', label: 'Country', type: 'string' },
            { field: 'City', label: 'City', type: 'string' }
        ];

        return new QueryBuilder({
            width: '100%',
            columns: columnsModel,
        })
    }


    public static GetParamSettingsQueryBuilder(columnsMdl: ColumnsModel[]): QueryBuilder {


        let columnData: ColumnsModel[] = [
            { field: 'EmployeeID', label: 'EmployeeID', type: 'number' },
            { field: 'FirstName', label: 'FirstName', type: 'string' },
            { field: 'TitleOfCourtesy', label: 'Title Of Courtesy', type: 'boolean', values: ['Mr.', 'Mrs.'] },
            { field: 'Title', label: 'Title', type: 'string' },
            { field: 'HireDate', label: 'HireDate', type: 'date', format: 'dd/MM/yyyy' },
            { field: 'Country', label: 'Country', type: 'string' },
            { field: 'City', label: 'City', type: 'string' }
        ];

        return new QueryBuilder({
            width: '100%',
            columns: columnsMdl,
        })
    }


}