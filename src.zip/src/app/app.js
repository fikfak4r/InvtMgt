define(["require", "exports", "@syncfusion/ej2-base", "@syncfusion/ej2-layouts", "@syncfusion/ej2-buttons", "jquery", "./app1", "./app2"], function (require, exports, ej2_base_1, ej2_layouts_1, ej2_buttons_1, $, app1_1, app2_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    ej2_base_1.enableRipple(true);
    let grandSplitter = new ej2_layouts_1.Splitter({
        width: "1005px",
        height: "100%",
        paneSettings: [{ size: "855px" }, { size: '265px' }]
    });
    grandSplitter.appendTo("#grand-splitter");
    let count = 1;
    let zIndexCount = 1000;
    let btn1 = new ej2_buttons_1.Button({
        cssClass: "e-success"
    }, '#btn1');
    let myQryBuilders = new Array();
    let qryModelDefRef = new Array();
    btn1.element.setAttribute('title', 'Get the query editor dialog');
    btn1.element.onclick = () => {
        ++count;
        $("#defaultDialog").after("<div id='dialog" + count + "'></div>");
        let dialog = app1_1.QryDialog.GetDialog(`Dialog ${count}`);
        dialog.close = () => {
            qryModelDefRef.find((x) => { return x.id == dialog.element.id; }).State = false;
        };
        dialog.appendTo("#" + app2_1.SmoothDataUtilities.GetModelDailogId(count));
        var qryModelDef = new app1_1.QryModelDef();
        qryModelDef.State = true;
        qryModelDef.id = dialog.element.id;
        var qrbldr = app1_1.QryQueryBuilder.GetQueryBuilder();
        qryModelDef.qryBldr = qrbldr;
        qrbldr.appendTo($(dialog.element).find('.e-dlg-content')[0]);
        app1_1.QryQueryBuilder.SetTemplate(qrbldr, qryModelDef);
        qryModelDefRef.push(qryModelDef);
        dialog.element.onmousedown = () => {
            let zIndx = 100000 + ++zIndexCount + 1;
            dialog.element.style.zIndex = zIndx.toString();
        };
        let btn2 = new ej2_buttons_1.Button({
            cssClass: "e-success"
        }, '#btn2');
        btn2.element.setAttribute('title', 'Get query');
        btn2.element.style.display = 'block';
        btn2.element.onclick = () => {
            qryModelDefRef
                .filter((obj, index, list) => { return obj.State == true; })
                .forEach((obj, index, list) => {
                alert(JSON.stringify(obj.qryBldr.getValidRules(obj.qryBldr.rule)));
                alert(JSON.stringify(obj.paramQryBldr.getValidRules(obj.paramQryBldr.rule)));
            });
        };
    };
});
