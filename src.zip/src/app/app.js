define(["require", "exports", "@syncfusion/ej2-popups", "@syncfusion/ej2-base", "@syncfusion/ej2-layouts", "@syncfusion/ej2-buttons", "jquery", "@syncfusion/ej2-querybuilder", "./datasource"], function (require, exports, ej2_popups_1, ej2_base_1, ej2_layouts_1, ej2_buttons_1, $, ej2_querybuilder_1, datasource_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    ej2_base_1.enableRipple(true);
    let grandSplitter = new ej2_layouts_1.Splitter({
        width: "1005px",
        height: "100%",
        paneSettings: [{ size: "855px" }, { size: '265px' }]
    });
    grandSplitter.appendTo("#grand-splitter");
    let count = 1;
    let btn1 = new ej2_buttons_1.Button({
        cssClass: "e-success"
    }, '#btn1');
    btn1.element.setAttribute('title', 'Get the query editor dialog');
    btn1.element.onclick = () => {
        ++count;
        $("#dialog1").after("<div id='dialog" + count + "'></div>");
        let dialog = QryDialog.GetDialog(`Dialog ${count}`);
        dialog.appendTo("#dialog" + count);
        QryQueryBuilder.GetQueryBuilder().appendTo($(dialog.element).find('.e-dlg-content')[0]);
        dialog.element.onmousedown = () => {
            let zIndx = 100000 + ++count + 1;
            dialog.element.style.zIndex = zIndx.toString();
        };
    };
    class QryDialog {
        constructor() { }
        static GetDialog(title) {
            let dialog = new ej2_popups_1.Dialog({
                header: title,
                width: "750px",
                overlayClick: () => { alert("So clicked"); },
                allowDragging: true,
                showCloseIcon: true,
                isModal: false,
                target: document.getElementById("container"),
                position: { X: 'left', Y: 'top' },
            });
            return dialog;
        }
        static RaiseFocus() {
        }
    }
    class QryQueryBuilder {
        constructor() {
        }
        static GetQueryBuilder() {
            let columnData = [
                { field: 'EmployeeID', label: 'EmployeeID', type: 'number' },
                { field: 'FirstName', label: 'FirstName', type: 'string' },
                { field: 'TitleOfCourtesy', label: 'Title Of Courtesy', type: 'boolean', values: ['Mr.', 'Mrs.'] },
                { field: 'Title', label: 'Title', type: 'string' },
                { field: 'HireDate', label: 'HireDate', type: 'date', format: 'dd/MM/yyyy' },
                { field: 'Country', label: 'Country', type: 'string' },
                { field: 'City', label: 'City', type: 'string' }
            ];
            return new ej2_querybuilder_1.QueryBuilder({
                width: '100%',
                columns: datasource_1.columnsModel,
            });
        }
    }
});
