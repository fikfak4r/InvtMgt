import { ColumnsModel } from "@syncfusion/ej2-querybuilder";

export interface QryParam {
     Category:string
      Template: string
        fields?: ColumnsModel[] 
}