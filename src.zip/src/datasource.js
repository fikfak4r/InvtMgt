define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.columnsModel = [
        { field: 'Retail' },
        { field: 'Transacting' },
        { field: 'TelecomCustomers' }
    ];
});
